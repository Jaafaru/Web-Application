
	<html> 
	  <head> 
	    <meta  http-equiv="Content-Type" content="text/html;  charset=iso-8859-1"> 
	    <title>Search  Contacts</title> 
	  </head> 
	  <p><body> 
	    <h3>Search  Contacts Details</h3> 
	    <p>You  may search either by first or last name</p> 
	    <form  method="post" action="search.php?go"  id="searchform"> 

<li>
                                    <a href="javascript:;#"><input type="checkbox" name="name" value="pinger.uum.edu.my"></input> pinger.uum.edu.my</a>
                                    <a href="javascript:;#"><input type="checkbox" name="name" value="pinger.uum.edu.my"></input> pinger.uum.edu.my</a>
                                </li>





<input type="checkbox" name="lastname" value="www.myren.net.my">www.myren.net.my</input><br/>
<input type="checkbox" name="lastname" value="www.mmu.edu.my">www.mmu.edu.my</input><br/>


	      
	      <input  type="submit" name="submit" value="Search"> 




	    </form> 




<?php 
	  if(isset($_POST['submit'])){ 
	  if(isset($_GET['go'])){ 
	  if(preg_match("/^[  A-Z | a-z]+/", $_POST['name']) && preg_match("/^[  A-Z | a-z]+/", $_POST['lastname'])){ 
	  $name=$_POST['name']; 
	  $lastname=$_POST['lastname'];
	  //connect  to the database 
	  $db=mysql_connect  ("localhost", "root",  "") or die ('I cannot connect to the database  because: ' . mysql_error()); 
	  //-select  the database to use 
	  $mydb=mysql_select_db("PINGERDB"); 
	  //-query  the database table 
	  $sql="SELECT  * FROM Reports WHERE Hostname LIKE '%" . $name .  "%' AND Remotename LIKE '%" . $lastname ."%'"; 
	  //-run  the query against the mysql query function 
	  $result=mysql_query($sql) or die ("invalid SQL query".mysql_error()); 
?>

<table border ="1">
                <tr>
                   
                    <th>Hostname</th>
                    <th>Remotename</th>
                    <th>Minimum</th>
                     <th>Average</th>
                     <th>Maximum</th>
                </tr>
 
<?php
//-create  while loop and loop through result set
 while ( $row = mysql_fetch_array($result))
     { ?>


     <tr>
                    <td><?php echo $row['Hostname'];?></td>
                    <td><?php echo $row['Remotename'];?></td>
                    <td><?php echo $row['Minimum'];?></td>
                    <td><?php echo $row['Average'];?></td>
                    <td><?php echo $row['Maximum'];?></td>
                </tr>


                <?php } ?>

                </table>


	  
    <?php
	  } 
	  else{ 
	  echo  "<p>Please enter a search query</p>"; 
	  } 
	  } 
	  } ?>



	  </body> 
	</html> 
	</p> 