<?php  
 require_once('DB.php');
 
 $output = '';  
 if(isset($_POST["export_excel"])){   
 
 $getdata = "SELECT  * FROM Reports WHERE Hostname LIKE '%" . $name .  "%' AND Remotename LIKE '%" . $lastname ."%'"; 
$data_res = mysql_query($getdata) or die ("invalid SQL query ".mysql_error());
     if(mysql_num_rows($data_res) > 0)  
      {  
      $output .= '  
         <table class="table" bordered="1">  
            <tr>  
                <th>Hostname</th>
                <th>RemoteName</th>
                <th>Minimum RTT</th>
                <th>Average RTT</th>
                <th>Maximum RTT</th>  
                     </tr>  
           ';  
           while($row = mysql_fetch_array($data_res)) 
           {  
             $output .= '  
              <tr>  
                <td>'.$row['Hostname'].'</td>  
                <td>'.$row['Remotename'].'</td>  
                <td>'.$row['Minimum'].'</td>  
						    <td>'.$row['Average'].'</td>  
                <td>'.$row['Maximum'].'</td>      
                     </tr>  
                '; 
           }  
           $output .= '</table>';  
           header("Content-Type: application/xls");   
           header("Content-Disposition: attachment; filename=data.xls");  
           echo $output; 
            }  
 }  
 ?>