<?php
$connection = mysql_connect("localhost","root","") or die('Could not connect: ' . mysql_error());
   mysql_select_db("PINGERDB", $connection);
  //$connection = mysqli_connect('localhost','root','','FEEED') or die(mysqli_error($connection));

?>