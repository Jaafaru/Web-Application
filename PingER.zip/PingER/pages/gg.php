<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
    <table align="center">
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Id:</td>
        <td><input type="text" name="id" value="" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Activity:</td>
        <td><input type="text" name="activity" value="" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Club:</td>
        <td><input type="text" name="club" value="" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">Image:</td>
        <td><label for="image"></label>
      <input id='upload' name="upload[]" type="file" multiple="multiple" /></td>
      </tr>
      <tr valign="baseline">
        <td nowrap="nowrap" align="right">&nbsp;</td>
        <td><input type="submit" value="Insert record" /></td>
      </tr>
  </table>
    <input type="hidden" name="MM_insert" value="form1" />
  </form>