
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PingER Worldwide History Reports</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
     <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0-rc2/css/bootstrap-glyphicons.css" rel="stylesheet" type="text/css">


  

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
<?php
require_once('DB.php');
?>

    <div id="wrapper">

        <!-- Navigation -->
        <form  method="post" action="index.php?go"  id="searchform">
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">PingER Worldwide Reports</a>
                
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
               
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-tasks fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-tasks">
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 1</strong>
                                        <span class="pull-right text-muted">40% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                            <span class="sr-only">40% Complete (success)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 2</strong>
                                        <span class="pull-right text-muted">20% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 20%">
                                            <span class="sr-only">20% Complete</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 3</strong>
                                        <span class="pull-right text-muted">60% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                                            <span class="sr-only">60% Complete (warning)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">
                                <div>
                                    <p>
                                        <strong>Task 4</strong>
                                        <span class="pull-right text-muted">80% Complete</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            <span class="sr-only">80% Complete (danger)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a class="text-center" href="#">
                                <strong>See All Tasks</strong>
                                <i class="fa fa-angle-right"></i>
                            </a>
                        </li>
                    </ul>
                    <!-- /.dropdown-tasks -->
                </li>
                
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="login.html"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

 <div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">

                    <li>
                            <a href="index.html"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                
                    <li class="active">

                    <a href="javascript:;" data-toggle="collapse" data-target="#metric"><i class="fa fa-bar-chart-o fa-fw">
                    </i> Metric<span class="fa fa-fw fa-caret-down"></span></a>
                            <ul id="metric" class="collapse">
                                
                                   <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="minimum round trip time"></input> Minimum Round Trip Time</a>
                                </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="mean opinion score"></input> Mean Opinion Score</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="directivity"></input> Directivity</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="minimum packet loss"></input> Minimum Packet Loss</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="maximum round trip time"></input> Maximum Round Trip Time</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="average round trip time"></input> Average Round Trip Time</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="conditional loss probability"></input> Conditional Loss Probability</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="duplicate packets"></input> Duplicate Packets</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="inter-packet delay variation"></input> Inter-Packet Delay Variation</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="inter-quartile range"></input> Inter-Quartile Range</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="out of order packets"></input> Out of Order Packets</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="packet loss"></input> Packet Loss</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="TCP throughput"></input> TCP Throughput(Kbits/s)</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="ping unpredictability"></input> Ping Unpredictability</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="ping unreachability"></input> Ping Unreachability</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="metric1" value="zero packet loss frequency"></input> Zero Packet Loss Frequency</a>
                                </div>
                      
                            </ul>

                    </li>


                    <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#from"><i class="fa fa-fw fa-sign-in">
                    </i> From<span class="fa fa-fw fa-caret-down"></span></a>
                            <ul id="from" class="collapse">
                               <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="name" value="pinger.uum.edu.my"></input>pinger.uum.edu.my</a>
                                </div>
                                    
                      
                            </ul>

                    </li>

                    <li>
                         <a href="javascript:;" data-toggle="collapse" data-target="#to"><i class="fa fa-fw fa-sign-out">
                         </i> To<span class="fa fa-fw fa-caret-down"></span></a>
                            <ul id="to" class="collapse">
                                  <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.myren.net.my"></input> www.myren.net.my</a>
                                </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.umt.edu.my"></input> www.umt.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.qiup.edu.my"></input> www.qiup.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.mmu.edu.my"></input> www.mmu.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.unikl.edu.my"></input> www.unikl.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.utar.edu.my"></input> www.utar.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.umk.edu.my"></input> www.umk.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.miu.edu.my"></input> www.miu.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.celcom.com.my"></input> www.celcom.com.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.mju.ac.th"></input> www.mju.ac.th</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="shinjiru.com.my"></input> shinjiru.com.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.maxis.com.my"></input> www.maxis.com.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="datakl.com"></input> datakl.com</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="emerge.com.my"></input> emerge.com.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.ubd.edu.bn"></input> www.ubd.edu.bn</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.itb.edu.bn"></input> www.itb.edu.bn</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.uinjkt.ac.id"></input> www.uinjkt.ac.id</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.itb.ac.id"></input> www.itb.ac.id</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.nus.edu.sg"></input> www.nus.edu.sg</a>
                                </div>
                                 <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="singaporetech.edu.sg"></input> singaporetech.edu.sg</a>
                                </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.ku.ac.th"></input> www.ku.ac.th</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.swu.edu.ph"></input> www.swu.edu.ph</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.auf.edu.ph"></input> www.auf.edu.ph</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.um.edu.my"></input> www.um.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.upsi.edu.my"></input> www.upsi.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.upnm.edu.my"></input> www.upnm.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.usim.edu.my"></input> www.usim.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.unisza.edu.my"></input> www.unisza.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.utem.edu.my"></input> www.utem.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.uum.edu.my"></input> www.uum.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="pinger.slac.stanford.edu"></input> pinger.slac.stanford.edu</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.afe.mr"></input> www.afe.mr</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.utm.my"></input> www.utm.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.utp.edu.my"></input> www.utp.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.allianzeunicollege.edu.my"></input> www.allianzeunicollege.edu.my</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.newinti.edu.my"></input> www.newinti.edu.my</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.mahsa.edu.my"></input> www.mahsa.edu.my</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.aiu.edu.my"></input> www.aiu.edu.my</a>
                                </div>

                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.nus.edu.sg"></input> www.nus.edu.sg</a>
                                </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.monash.edu.my"></input> www.monash.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.ocesb.com.my"></input> www.ocesb.com.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.sabah.com.my"></input> www.sabah.com.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.usu.ac.id"></input> www.usu.ac.id</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.unri.ac.id"></input> www.unri.ac.id</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.ugm.ac.id"></input> www.ugm.ac.id</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.unair.ac.id"></input> www.unair.ac.id</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.untan.ac.id"></input> www.untan.ac.id</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.mib.edu.my"></input> www.mib.edu.my</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="frcu.eun.eg"></input> frcu.eun.eg</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="waib.gouv.bj"></input> waib.gouv.bj</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www-05.nexus.ao"></input> www-05.nexus.ao</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.gov.bw"></input> www.gov.bw</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.afrinet.cd"></input> www.afrinet.cd</a>
                                    </div>
                                    <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.assemblee.bi"></input> www.assemblee.bi</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.univ-koudougou.bf"></input> www.univ-koudougou.bf</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.stmaryuniversitycollege.edu.et"></input> www.stmaryuniversitycollege.edu.et</a>
                                </div>
                                <div class="checkbox">
                                    <a href="#"><input type="checkbox" name="lastname" value="www.andi.dz"></input> www.andi.dz</a>
                                </div>
                      
                            </ul>
                    </li>

                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#exclude"><i class="fa fa-fw fa-arrows-v"></i> Excluding <i class="fa arrow"></i></a>
                        <ul id="exclude" class="collapse">
                            
                            
                        </ul>
                    </li>


                    <li>
                         <a href="javascript:;" data-toggle="collapse" data-target="#time"><i class="fa fa-fw fa-clock-o"></i> Time <i class="fa arrow"></i></a>
                        <ul id="time" class="collapse">
                            
                            <div class="form-group">

                            <label for="sel1">By:<select class="form-control" id="sel1">
                                <option>by-node</option>
                                <option>by-site</option>
                              </select></label>
                              <br>
                
                             <label for="sel2">For Packet Size (bytes):<select class="form-control" id="sel2">
                                <option>100</option>
                                <option>1000</option>
                              </select></label>
                              <br>

                               <label for="sel3">Tick-Type:<select class="form-control" id="sel3">
                                <option>hourly</option>
                                <option>daily</option>
                                <option>last-60-days</option>
                                <option>last-120-days</option>
                                <option>last-365-days</option>
                                <option>all-monthly</option>
                                <option>monthly</option>
                                <option>all-yearly</option>
                              </select></label>
                              <br>

                              <label for="sel4">Show:<select class="form-control" id="sel4">
                                <option>all</option>
                                <option>beacon</option>
                                <option>monitor</option>
                                <option>remote</option>
                                <option>www</option>
                              </select> nodes</label>
                              <br>

                              <label for="sel5">Change the dataset:<select class="form-control" id="sel5">
                                <option>new</option>
                                <option>hep</option>
                              </select></label>
                              <br>

                               <label for="sel6">Only show sites with:<select class="form-control" id="sel4">
                                <option>any</option>
                                <option>75%</option>
                                <option>50%</option>
                            
                              </select> datapoints</label>
                              <br>

                              </div>
                            
                        </ul>
                    </li>
                    
                    <li>
                        <div class="button">
                             
                          <input type="submit" name="submit" class="btn btn-success" value="Submit" /> 
                           
                          </div> 
                     
                    </li>

                </ul>
                
            </div>
        </div>
        </nav>
        </form>


        

        




        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Internet End-To-End Performance Measurement</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
 

 <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-globe fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">26</div>
                                    <div>Google map of Sites</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-tasks fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">12</div>
                                    <div>Ongoing Research</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-group fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">14</div>
                                    <div>Activate Group</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-file fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">13</div>
                                    <div>PingER Files</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

<div class="row">
<div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Summary
                            <div class="pull-right">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                        Actions
                                        <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu pull-right" role="menu">
                                        <li><a href="http://localhost/PingER/pages/display.php">Save</a>
                                        </li>
                                        <li><a ><span class="box">
<form action="excel.php" method="post"><input type="submit" name="export_excel" class="btn btn-success" value="Export to Excel" /></form>
</span></a>
                                        </li>
    

                                        <li class="divider"></li>
                                        <li><a href="#">Separated link</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- /.panel-heading -->
                         
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                            
<table class="table table-striped table-bordered table-hover" id="dataTables-example"> 
     <thead>
           <tr>
                  <th>Hostname</th>
                  <th>RemoteName</th>
                  <th>Minimum RTT</th>
                  <th>Average RTT</th>
                  <th>Maximum RTT</th>
                                       </tr>
                                   </thead>

<?php 
      if(isset($_POST['submit'])){ 
      if(isset($_GET['go'])){ 
      if(preg_match("/^[  A-Z | a-z]+/", $_POST['name']) && preg_match("/^[  A-Z | a-z]+/", $_POST['lastname'])){ 
      $name=$_POST['name']; 
      $lastname=$_POST['lastname'];
      //connect  to the database 
      //$db=mysql_connect  ("localhost", "root",  "") or die ('I cannot connect to the database  because: ' . mysql_error()); 
      //-select  the database to use 
      //$mydb=mysql_select_db("PINGERDB"); 
      //-query  the database table 
      $sql="SELECT  * FROM Reports WHERE Hostname LIKE '%" . $name .  "%' AND Remotename LIKE '%" . $lastname ."%'"; 
      //-run  the query against the mysql query function 
      $result=mysql_query($sql) or die ("invalid SQL query".mysql_error()); 

?>

                                     <?php	
				  //$sql = "SELECT * FROM Reports"; 
					//$result = mysql_query($sql) or die ("invalid SQL query ".mysql_error());

          while($row = mysql_fetch_array($result))
          {
             $id = $row['Hostname'];
             $message =$row['Remotename'] ;
             $fromName = $row['Minimum'];
             $fromId= $row['Average'];
             $link = $row['Maximum'] ;




          ?>                               
                                          					
					<tbody>
                    <tr class="odd gradeX">
                    <td><?php echo "".$id ?></a></td>
					<td><?php echo "".$message?></td>
                    <td><?php echo "".$fromName ?></td>
                    <td><?php echo "".$fromId ?></td>
                    <td><?php echo "".$link ?></td>           
	 </tr>
                 </tbody>
		
					<?php 
					} 
					?>
                    
				  </table>


                  <?php

      } 
      else{ 
      echo  "<p>Please enter a search query</p>"; 
      } 
      } 
      } ?>
                                            
                        </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>


                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Area Chart Example
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div id="morris-area-chart"></div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>



                <div class="col-lg-12">
                    <div class="panel panel-default">
                     
                        <div class="panel-body">
                            <p>This report took 2 seconds to create. It is available with hourly, daily, monthly and yearly ticks . For data earlier than 2007 See Retrieving PingER Historical Data 
Created by pingtable.pl Version 3.1, Les Cottrell 6/29/2015 from /nfs/slac/g/net/pinger/pingerreports/hep/average_rtt/average_rtt-100-by-node-allyears.txt.gz that was last modified Fri Apr 1 19:07:00 2016.</p> 

<p>Used configuration files: /afs/slac/package/pinger/pinger.new.cf, node file /afs/slac/package/pinger/nodes.cf and filter file /afs/slac/g/www/www-iepm/pinger/slaconly/pingtable_filter.cfg. 
Used library files: /afs/slac/g/www/cgi-bin/cgi-lib.pl and /afs/slac/g/www/cgi-wrap-bin/net/offsite_mon/pinghistory/new/mon-lib.pl
See <a target="_blank" href="http://www-iepm.slac.stanford.edu/pinger/tools/restoredata.html">Restoring PingER Historical Data</a>for how the data pingtable.pl presents is created.</p> <p> Comments and Questions to <a href="cottrell@slac.stanford.edu">Les Cottrell</a> </p>
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>



                </div>


        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
