<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
   
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>

    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
    <img id = "brief-text" src="images/logo.jpg" align = "left"> 

   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>    
  </div>
</div>
</div>

<center>
<?php

$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");
//$ID = $_POST['id'];
	$fname = $_POST['fName'];
	$lname = $_POST['lName'];
	$pass = $_POST['pW'];
    $rePass = $_POST['pWW'];
    $hAdd = $_POST['hAdd'];
	$pAdd = $_POST['pAdd'];
	$city = $_POST['city'];
    $region = $_POST['region'];
    $zipCode = $_POST['zipCode'];
	$country = $_POST['ctry'];
    $email = $_POST['myEmail'];
    $pNum = $_POST['pNumber'];
    $mailList = $_POST['usertel'];


$sql = $connection->prepare("UPDATE users SET firstName='$fname', lastName='$lname', password='$pass', rePassword='$rePass', homeAddress='$hAdd', presentAddress='$pAdd', city='$city', region='$region', zipCode='$zipCode', Country='$country', email='$email', phoneNumber='$pNum', mailList='$mailList' WHERE email ='$email'");
  
   $sql->execute();

echo " 
<script language='javascript'> 
alert('Your Account has been updated!')
</script> ";

echo "<h1>Record updated</h1>";
    echo "<table>";
    echo "<tr>";
    echo "<td>First Name: </td>";
    echo "<td>$fname </td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Last Name: </td>";
    echo "<td>$lname </td>";
    echo "<tr>";
    echo "<td>Home Address: </td>";
    echo "<td>$hAdd </td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Present Address: </td>";
    echo "<td>$pAdd </td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Phone Number: </td>";
    echo "<td>$mailList </td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Email Address: </td>";
    echo "<td>$email </td>";
    echo "</tr>";
    echo "</table>";

 
?>
</center>
</body>
</html>