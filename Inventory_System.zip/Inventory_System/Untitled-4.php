<?php if(isset($_GET['subs'])){
$name = $_GET['name'];
	$add = $_GET['add'];
 $sql = $connection->query("insert into shipping_details values ('','$name', '$add',NOW()) ");
  }
?>

    <form action="" method="get">
  <table  border="0" align="center" cellpadding="5"  cellspacing="5">
  <tr>
    <td>Name</td>
    <td><span id="sprytextfield1">
      <input type="text" name="name" id="name" required>
      <span class="textfieldRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><span id="sprytextfield2">
      <input type="text" name="add" id="add" required>
      <span class="textfieldRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td align="center" colspan="2"><input type="submit" name="sub" id="subs" value="Submit"></td>
   </tr>
 </table>

    
    </form>

