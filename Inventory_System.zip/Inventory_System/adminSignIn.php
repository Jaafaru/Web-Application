<?php include('sess.php');
$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");
if(isset($_POST['login'])){
	
    $uName = $_POST['aName'];			
    $pass = $_POST['aPass'];


	$sql = $connection->query("select * from admin where username = '$uName' and password = '$pass'");
				$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
		if ($no ==1)
		 {
			 $row = $sql->fetch();
			 
			 $_SESSION['aName'] = $uName;
			 
			header("Location: adminHomepage.php");
	     }else{
				$msg =  "This is an admin session. Enter a valid admin username and password !!!";}	
				}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>
    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>      
  </div>
</div>
</div>
<form name="admin" method="post" action="">

 <table border="0" align="center">
 <tr>
    <td colspan="2">
       <?php if(isset($msg)) echo $msg;?>
    </td>
 </tr>
 <tr>
    <td colspan="2">
       <h1>Admin Login</h1>
    </td>
 </tr>
  <tr>
    <td>
        Username:
    </td>
    <td>
        <input type="text" name="aName" required>
    </td>
  </tr>
  <tr>
    <td>
        Password:
    </td>
    <td>
        <input type="password" name="aPass" required>
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center">
      <input type="submit" name="login" value="Login">
    </td>
  </tr>
 </table>
 <center>
 Not registered? <a href="adminSignUp.html" >Create Account</a>
 </center>
</form>



<form action="adminLog.php" method="post">
<input type="submit" name="adminLogout" value="Logout" align="right">
</form>
</body>
</html>