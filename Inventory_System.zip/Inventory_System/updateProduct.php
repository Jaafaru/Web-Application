<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="addProduct.html">Add New Product</a></li>
      <li><a href="editProduct.html">Edit a product</a></li>
      <li><a href="searchProduct.html">Search for a product</a></li>
      <li><a href="viewAllProduct.php">View All Products</a></li>
      <li><a href="deleteProduct.html">Delete Product</a></li>

    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
    <img id = "brief-text" src="images/logo.jpg" align = "left"> 

   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>    
  </div>
</div>
</div>

<center>
<?php
$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");

    $pID = $_POST['prodID'];
	$pType = $_POST['prodType'];
	$pName = $_POST['prodName'];
    $pSize = $_POST['prodSize'];
    $pPrice = $_POST['prodPrice'];
	
	$pDesc = $_POST['prodDesc'];

	
	$imgFile = $_FILES['prodImage']['name'];
	$tmp_dir = $_FILES['prodImage']['tmp_name'];
	$imgSize = $_FILES['prodImage']['size'];

    $upload_dir = '';
	$imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION));
	$valid_extensions = array('jpeg', 'jpg', 'png', 'gif');
	$pImage = rand(1000,1000000).".".$imgExt;
	 if(in_array($imgExt, $valid_extensions)){
		 if($imgSize < 5000000){
			 move_uploaded_file($tmp_dir, $upload_dir.$pImage);
		 }
		 else{
			 $errMSG = "Sorry, your file is too large.";
		 }
	 }
	 else{
		 $errMSG = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
	 }
	 
 $sql =  "UPDATE product SET pSize='$pSize', pPrice='$pPrice', pImage= '$pImage', pDesc= '$pDesc'  WHERE pID ='$pID'";
//prepare statement
$result = $connection->prepare($sql);
//execute the query
$result->execute();

 echo " 
<script language='javascript'> 
alert('A product has been updated!')
</script> ";

echo "<h1>Record updated</h1>";
	echo "<table>";
	echo "<tr>";
	echo "<td>Product ID: </td>";
	echo "<td>$pID </td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>Product Type: </td>";
	echo "<td>$pType </td>";
	echo "<tr>";
	echo "<td>Product Name: </td>";
	echo "<td>$pName </td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>Product Size: </td>";
	echo "<td>$pSize </td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>Product Price: </td>";
	echo "<td>$pPrice </td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Image: </td>";
	echo '<td><img src="'.$pImage.'" alt="HTML5 Icon"></td>';
    echo "</tr>";
	echo "<tr>";
	echo "<td>Product Desc: </td>";
	echo "<td>$pDesc </td>";
    echo "</tr>";
	echo "</table>";
	?>
</center>
</body>
</html>