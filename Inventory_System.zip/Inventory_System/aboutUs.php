<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
#container{ 
 width:100%;
 border:#CCC;
}
#about_sec{
	width:100%;
	height:700px;
}

</style>
</head>

<body bgcolor="#CCCCCC">
<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.html">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>
    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>      
  </div>
</div>
</div>


<h1 align="center"><strong>ABOUT US</strong></h1>

<div id = "container">
<br><br>
  <div id = "about_sec"> 
  <img id = "aboutImg" src="images/gadgets.jpg" align = "left" width="500" height="400">
  <div id="textsec"> 
  <p style="font-weight:300" align="center"><em><strong> PS Electronic Online Shop is an website that deals in the selling of new and quality smart phones and laptops. <br> Our vision is to provide best valued products to our customers across the Globe.. <br> Our website offers best prices. Some of the top selling electronics brand are samsung, apple, dell, HP, LG, Sony and so many more.</strong></em></p>  
  </div>    
  </div>
</div>
</body>
</html>