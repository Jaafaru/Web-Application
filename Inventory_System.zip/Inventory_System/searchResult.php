<html>
<head>

<link rel="stylesheet" type="text/css" href="style.css">

<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
th {
    text-align: centre;
}
</style>
</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="addProduct.html">Add New Product</a></li>
      <li><a href="editProduct.html">Edit a product</a></li>
      <li><a href="searchProduct.html">Search for a product</a></li>
      <li><a href="viewAllProduct.php">View All Products</a></li>
      <li><a href="deleteProduct.html">Delete Product</a></li>

    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
  
   <img id = "brief-text" src="images/logo.jpg" align = "left"> 

   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>    
  </div>
</div>
</div>
<center>
<?php
$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");

if (isset($_POST["sPType"]))
{
$sPType=$_POST["sPType"];
// execute SQL SELECT query
$sql = $connection->query("SELECT * FROM product where pType = '$sPType'");
$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}
else
	// number of returned columns
	//$cols = $sql->columnCount();  // returns number of column in the result set
	//echo 'Number of returned columns: ' . $cols. '<br>';
	// Parse the result set & extract specific fields
	?> 
<table border="1" style="width:80%" align="center" cellpadding="5">
<tr>
    <th>ID</th>
    <th>Type</th>
    <th>Name</th>
    <th>Size</th>
    <th>Price</th>
    <th>Image</th> 
    <th>Specification</th> 

</tr>
<?php
	foreach($sql as $row)
	{
	   $pID = $row['pID'];
	   $pType= $row['pType'];
	   $pName = $row['pName'];
	   $pSize = $row['pSize'];
	   $pPrice= $row['pPrice'];  
	   $pImage = $row['pImage']; 
	   $pDesc = $row['pDesc']; 

	   echo 
	"<tr>
	<td>$pID</td>
    <td>$pType</td>
    <td>$pName</td>
    <td>$pSize</td>
    <td>$pPrice</td>";
    echo '<td><img src="'.$pImage.'" alt="HTML5 Icon" style="width:128px;height:128px"></td>';
	echo "<td>$pDesc</td>";
    echo "</tr>\n";
	}
	}
	echo '</table>';

?>
</center>
</body>
</html>