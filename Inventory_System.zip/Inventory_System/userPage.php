<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">


<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.html">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>
    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>      
  </div>
</div>
</div>
</head>
</html>

<?php session_start();
 $connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");

 function makepay(){
	 ?>
     
     <form action="" method="get">
     <table width="200" border="1">
  <tr>
    <td>Pay</td>
    <td><input type="submit" name="pay" value="Submit"></td>
  </tr>
</table>

     </form>
     <?php 
	 }

?>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
th {
    text-align: centre;
}
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>
</html>

<?php
if(isset($_POST['subs'])){
	echo '<h1><strong>Congratulations!! Your payment was successful <strong><h1>';
	echo '<img src="images/thanks.JPG"><br>';
	echo  '<h2><strong>A total of RM'.$_SESSION['sum'] .'  was paid <strong><h2>';
	exit();
}
if(isset($_POST['sub'])){
	$sum = 0 ;
	echo '<form method="post"><table border="1" style="width:80%" align="center" cellpadding="5">
<tr>
      <th>Type</th>
    <th>Name</th>
    <th>Size</th>
    <th>Price</th>
    <th>Image</th> 
 	';

	foreach($_POST['gs'] as $k){
		//echo $k;
		$sql = $connection->query("SELECT * FROM product where pID = '$k'");
		$no=$sql->rowCount();    

$row = $sql->fetch();
 	   $pType= $row['pType'];
	   $pName = $row['pName'];
	   $pSize = $row['pSize'];
	   $pPrice= $row['pPrice'];  
	   $pImage = $row['pImage']; 
 ?>
	
	<tr>
     <td><?php echo "".$pType ?></td>
    <td><?php echo "".$pName ?></td>
    <td><?php echo "".$pSize ?></td>
    <td> RM <?php echo "".$pPrice ?></td>
    <?php echo '<td><img src="'.$pImage.'" alt="HTML5 Icon" style="width:128px;height:128px"></td>';
 	 $sum = $sum +  $pPrice;
	
	
		}?> 
		
		<?php
		$_SESSION['sum'] = $sum;?>
		   </tr>
	<tr><td>Sum</td><td> RM <?php echo "".$sum?></td></tr><tr><td>Credit card Number</td><td><input type="number" name="cardnumber"></td></tr><tr><td>Expiry Date (MM/DD/YYYY)</td><td><input type="Date" name="edate"></td></tr>
	<tr><td>Name on Card</td><td><input type="text" name="cardname"></td></tr>
	<tr><td>Pay</td><td><input name="subs" type="submit"><input name="sum" type="hidden" value="'.$sum.'"></td></tr>
	</table></form>
	<!--if(isset()){}-->
	
	<!--//$pay = makepay();-->
	<?php
	 //$_SESSION['id'] = $us;
	if(isset($_SESSION['id'])){
	$us = $_SESSION['id'];
$sql = $connection->query("SELECT * FROM users where id = '$us'");
	$rows = $sql->fetch();
	 
	$na = $rows['firstName'];
	$add = $rows['presentAddress'];
	//echo $add;
	echo $na;
$sqla = $connection->prepare("INSERT INTO shipping_details values( '', '$na', '$add',NOW())");
   if($sqla->execute())$s ='s'; //echo 's';  
   else echo $sqla->errorInfo();
   

	foreach($_POST['gs'] as $k){
		//echo $k;
		
		$sqls = $connection->prepare("INSERT INTO order_details values ('','$k','$us',NOW())");
		if($sqls->execute()) $s ='s'; else echo $sqls->errorInfo(); 
		}//for
	}
		
exit();
}
$sql = $connection->query("SELECT * FROM product");
$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}
else
	// number of returned columns
	//$cols = $sql->columnCount();  // returns number of column in the result set
	//echo 'Number of returned columns: ' . $cols. '<br>';
	// Parse the result set & extract specific fields
	?>
    <form action="" method="post">
  <table border="0"  style="width:80%" align="center" cellpadding="5">
  <tr>
    <th>Selection</th>
    <th>ID</th>
    <th>Type</th>
    <th>Name</th>
    <th>Size</th>
    <th>Price</th>
    <th>Image</th> 
    <th>Specification</th> 
    
  </tr>
  <?php
	foreach($sql as $row)
	{
	   $pID = $row['pID'];
	   $pType= $row['pType'];
	   $pName = $row['pName'];
	   $pSize = $row['pSize'];
	   $pPrice= $row['pPrice'];  
	   $pImage = $row['pImage']; 
	   $pDesc = $row['pDesc']; 

	   echo 
	"<tr>
	<td><input name='gs[]' type='checkbox' value={$row['pID']}></td>
	<td>$pID</td>
    <td>$pType</td>
    <td>$pName</td>
    <td>$pSize</td> "?>

    <td>RM <?php echo "".$pPrice ?></td>
    <?php
    echo '<td><img src="'.$pImage.'" alt="HTML5 Icon" style="width:128px;height:128px"></td>';
	echo "<td>$pDesc</td>";
	}
    echo "</tr>\n";
	echo '<tr><td><input name="sub" type="submit"></td></tr></table>';
	 
?>
</form> 

 <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
 </script>
