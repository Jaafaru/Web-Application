<?php

$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");

    $name = $_POST['name'];
	$email = $_POST['aEmail'];
	$uName = $_POST['userName'];
    $pass = $_POST['aPass'];
    $pNum = $_POST['aTel'];
	
$sql = $connection->prepare("INSERT INTO admin (adminID, name,  email, username, password, phoneNumber) VALUES ('','$name', '$email', '$uName', '$pass', '$pNum')");

   $sql->execute();
 
?>