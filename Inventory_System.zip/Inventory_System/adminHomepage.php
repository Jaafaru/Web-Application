<?php 
session_start();
$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");
if(isset($_SESSION['aName']))
{

	$email = $_SESSION['aName']
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="jquery.cycle.all.js"></script>
<style>

#images{
	position: relative;
	width: 100%;
	top: 2px;
	height: 370px;
	display: block;
	float: left;
	overflow: hidden;
	}
#use{
	position: absolute;
	left: 5px;
	top: 69px;
	height: 60px;
	width: 100%;
	color: #FFF;
	font-size: 25px;
} 
</style>

<meta charset="utf-8">
<title>Untitled Document</title>

<script type="text/javascript">
$('#images').cycle({
	 fx:'scrollHorz',
	speed:'slow', 
    
	
	});
</script>
</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
<span id="use"> 
<h5>You have successfully logged in as <?php echo "".$_SESSION['aName']; ?></h5>
</span>
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="addProduct.html">Add New Product</a></li>
      <li><a href="editProduct.html">Edit a product</a></li>
      <li><a href="searchProduct.html">Search for a product</a></li>
      <li><a href="viewAllProduct.php">View All Products</a></li>
      <li><a href="deleteProduct.html">Delete Product</a></li>

    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>    
  </div>
</div>
</div>
<div id = "images">   
 <img src="images/mac-13-retina.jpg" width="100%" height="370px">
 <img src="images/bgImage.jpg" width="100%" height="370px">
 <img src="images/gadgets.jpg" width="100%" height="370px">
 <img src="Apple_Macbook_Pro_13.jpg" width="100%" height="370px">
 <img src="samsungGS6.jpg" width="100%" height="370px">
 <img src="asustaichi.jpg" width="100%" height="370px">
 <img src="images/lap1.jpg" width="100%" height="370px">
 <img src="images/lap2.jpg" width="100%" height="370px">
 <img src="images/lap3.jpg" width="100%" height="370px">
 <img src="images/pho1.jpg" width="100%" height="370px">
 
</div>
 
<?php
	
}
else
{
	?>
    <script>alert('Please login to view this page');</script>
    <?php
	
}
?>
