<?php include('sess.php');
$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");
if(isset($_POST['sub'])){
	$email = $_POST['email'];
				$pass = $_POST['pass'];
				$sql = $connection->query("select * from users where email = '$email' and password = '$pass'");
				$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
		if ($no ==1)
		 {
			 $row = $sql->fetch();

			 $_SESSION['email'] = $email;
			header("location: homepage.php");
			}else{
				$msg =  "Your username or password is invalid";}	
				}
?>
<!doctype html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="signIn.css">
<meta charset="utf-8">
<title>Log in</title>
<style>
</style>
<script language="javascript">
$( document ).ready(function() {
   
    loadProfile();
});


function getLocalProfile(callback){
    var profileImgSrc      = localStorage.getItem("PROFILE_IMG_SRC");
    var profileName        = localStorage.getItem("PROFILE_NAME");
    var profileReAuthEmail = localStorage.getItem("PROFILE_REAUTH_EMAIL");

    if(profileName !== null
            && profileReAuthEmail !== null
            && profileImgSrc !== null) {
        callback(profileImgSrc, profileName, profileReAuthEmail);
    }
}

/**
 * Main function that load the profile if exists
 * in localstorage
 */
function loadProfile() {
    if(!supportsHTML5Storage()) { return false; }
    // we have to provide to the callback the basic
    // information to set the profile
    getLocalProfile(function(profileImgSrc, profileName, profileReAuthEmail) {
        //changes in the UI
        $("#profile-img").attr("src",profileImgSrc);
        $("#profile-name").html(profileName);
        $("#reauth-email").html(profileReAuthEmail);
        $("#inputEmail").hide();
        $("#remember").hide();
    });
}

/**
 * function that checks if the browser supports HTML5
 * local storage
 *
 * @returns {boolean}
 */
function supportsHTML5Storage() {
    try {
        return 'localStorage' in window && window['localStorage'] !== null;
    } catch (e) {
        return false;
    }
}

/**
 * Test data. This data will be safe by the web app
 * in the first successful login of a auth user.
 * To Test the scripts, delete the localstorage data
 * and comment this call.
 *
 * @returns {boolean}
 */
function testLocalStorageData() {
    if(!supportsHTML5Storage()) { return false; }
    localStorage.setItem("PROFILE_IMG_SRC", "//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" );
    localStorage.setItem("PROFILE_NAME", "César Izquierdo Tello");
    localStorage.setItem("PROFILE_REAUTH_EMAIL", "oneaccount@gmail.com");
}
</script>
<style>

</style>
</head>

<body bgcolor="#CCCCCC">
<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>
    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online shopping enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em>      
  </div>
</div>
</div>
 
<!--
    you can substitue the span of reauth email for a input with the email and
    include the remember me checkbox
    -->
    <div class="container">
        <div class="card card-container">
            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
            <img id="profile-img" class="profile-img-card" src="images/avatar_2x.png" />
            <p id="profile-name" class="profile-name-card"></p>
           <?php if(isset($msg)) echo $msg;?>
            <form class="form-signin" method="post" action="">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="email" name="email" id="inputEmail" class="form-control" placeholder="User Name" required autofocus>
                <input type="password" name="pass" id="inputPassword" class="form-control" placeholder="Password" required>
                <div id="remember" class="checkbox">
                    <label>
                        <input type="checkbox" value="remember-me">Remember Me!
                    </label>
                </div>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name="sub">Login</button>
            </form><!-- /form -->
            <a href="#" class="forgot-password">
                Forgot your password?
            </a>&nbsp;|&nbsp; <a href="signUp.php" class="member">
                Not a Member?
            </a>
        </div><!-- /card-container -->
    </div><!-- /container -->
</body>
</html>