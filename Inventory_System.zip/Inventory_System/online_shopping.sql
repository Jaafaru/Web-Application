-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2016 at 05:27 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(10) NOT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phoneNumber` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `name`, `email`, `username`, `password`, `phoneNumber`) VALUES
(1, 'Tobi', 'samirahadebayo@gmail.com', 'tobi11', 'tobi12345', '0169768095');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(3) NOT NULL,
  `Name` varchar(15) NOT NULL,
  `Email` varchar(15) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Message` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `Name`, `Email`, `Subject`, `Message`) VALUES
(1, 'Semirah', 'semiling@yahoo.', 'Inquiries', 'How much is lenovo 560?');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `orderID` int(10) NOT NULL,
  `pID` int(10) NOT NULL,
  `userId` int(7) NOT NULL,
  `orderDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`orderID`, `pID`, `userId`, `orderDate`) VALUES
(1, 1, 3, '2016-06-06'),
(2, 1, 3, '2016-06-06'),
(3, 2, 3, '2016-06-06'),
(4, 2, 3, '2016-06-06'),
(5, 1, 3, '2016-06-06'),
(6, 2, 3, '2016-06-06'),
(7, 1, 3, '2016-06-06'),
(8, 3, 3, '2016-06-06'),
(9, 1, 3, '2016-06-06'),
(10, 3, 3, '2016-06-06'),
(11, 1, 3, '2016-06-06'),
(12, 3, 3, '2016-06-06'),
(13, 1, 3, '2016-06-06'),
(14, 2, 3, '2016-06-06'),
(15, 1, 3, '2016-06-06'),
(16, 2, 3, '2016-06-06'),
(17, 1, 3, '2016-06-07'),
(18, 3, 3, '2016-06-07'),
(19, 2, 0, '2016-06-07'),
(20, 3, 0, '2016-06-07'),
(21, 1, 0, '2016-06-07'),
(22, 2, 0, '2016-06-07'),
(23, 1, 0, '2016-06-07'),
(24, 3, 0, '2016-06-07'),
(25, 2, 0, '2016-06-07'),
(26, 3, 0, '2016-06-07'),
(27, 1, 0, '2016-06-13'),
(28, 3, 0, '2016-06-13'),
(29, 5, 0, '2016-06-13'),
(30, 2, 0, '2016-06-13'),
(31, 3, 0, '2016-06-13'),
(32, 1, 0, '2016-06-13'),
(33, 1, 0, '2016-06-13'),
(34, 2, 0, '2016-06-13'),
(35, 5, 0, '2016-06-13'),
(36, 3, 0, '2016-06-13'),
(37, 3, 0, '2016-06-13'),
(38, 6, 0, '2016-06-13'),
(39, 1, 0, '2016-06-17'),
(40, 1, 0, '2016-06-17'),
(41, 6, 0, '2016-06-17'),
(42, 6, 0, '2016-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pID` int(10) NOT NULL,
  `pType` varchar(30) NOT NULL,
  `pName` varchar(30) NOT NULL,
  `pSize` int(15) NOT NULL,
  `pPrice` double NOT NULL,
  `pImage` blob NOT NULL,
  `pDesc` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pID`, `pType`, `pName`, `pSize`, `pPrice`, `pImage`, `pDesc`) VALUES
(0, '', '', 0, 0, '', ''),
(1, 'type1', 'Sam45', 15, 1200, 0x3937343937312e6a7067, '       slim'),
(3, 'Lenovo', 'L11', 24, 4500, 0x3531313031382e6a7067, '       cxzxcvbnm,fdrtyjk '),
(5, 'ertry', 'asdfg', 12, 1234, 0x3132363534352e6a7067, '    werktknork     '),
(6, 'Lenovo', 'L123', 10, 5000, 0x3533343238302e6a7067, '     FLAT   '),
(7, 'Lenovo', 'L122', 12, 2400, 0x3832393135312e6a7067, '    flat    ');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_details`
--

CREATE TABLE `shipping_details` (
  `shpID` int(10) NOT NULL,
  `shipName` varchar(20) NOT NULL,
  `shipAddress` varchar(50) NOT NULL,
  `shipDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping_details`
--

INSERT INTO `shipping_details` (`shpID`, `shipName`, `shipAddress`, `shipDate`) VALUES
(1, 'Sameerah', 'Eon', '2016-06-06'),
(2, 'Sameerah', 'Eon', '2016-06-06'),
(3, 'Sameerah', 'Eon', '2016-06-06'),
(4, 'Sameerah', 'Eon', '2016-06-06'),
(5, 'Sameerah', 'Eon', '2016-06-06'),
(6, 'Sameerah', 'Eon', '2016-06-06'),
(7, 'Sameerah', 'Eon', '2016-06-06'),
(8, 'Sameerah', 'Eon', '2016-06-06'),
(9, 'Sameerah', 'Eon', '2016-06-06'),
(10, 'Sameerah', 'Eon', '2016-06-06'),
(11, 'Sameerah', 'Eon', '2016-06-07'),
(12, '', '', '2016-06-07'),
(13, '', '', '2016-06-07'),
(14, '', '', '2016-06-07'),
(15, '', '', '2016-06-07'),
(16, '', '', '2016-06-13'),
(17, '', '', '2016-06-13'),
(18, '', '', '2016-06-13'),
(19, '', '', '2016-06-13'),
(20, '', '', '2016-06-13'),
(21, '', '', '2016-06-13'),
(22, '', '', '2016-06-13'),
(23, '', '', '2016-06-13'),
(24, '', '', '2016-06-13'),
(25, '', '', '2016-06-13'),
(26, '', '', '2016-06-13'),
(27, '', '', '2016-06-17'),
(28, '', '', '2016-06-17'),
(29, '', '', '2016-06-17'),
(30, '', '', '2016-06-17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(40) NOT NULL,
  `password` varchar(30) NOT NULL,
  `rePassword` varchar(20) NOT NULL,
  `homeAddress` varchar(100) NOT NULL,
  `presentAddress` varchar(100) NOT NULL,
  `city` varchar(40) NOT NULL,
  `region` varchar(50) NOT NULL,
  `zipCode` int(12) NOT NULL,
  `Country` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phoneNumber` varchar(13) NOT NULL,
  `mailList` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `password`, `rePassword`, `homeAddress`, `presentAddress`, `city`, `region`, `zipCode`, `Country`, `email`, `phoneNumber`, `mailList`) VALUES
(1, '$fname', '$lname', '$pass', '$rePass', '$hAdd', '$pAdd', '$city', '$region', 0, '$country', '$email', '$pNum', '$mailList'),
(2, 'Ganiyah', 'Saleeman', '123456', '', 'Kaduna', 'Maybank', 'Alor setar', 'North', 6013, '', 'ganiyatsaleeman@gmail.com', '019', '736254562'),
(3, 'Sameerah', 'Adebayo', '1234', '1234', 'No 36, Eliozu', 'Eon', 'Kedah', 'North', 6010, 'Malaysia', 'semiling@yahoo.com', '0169768095', 'Yes'),
(4, 'Peace', 'Odeta', '123456', '123456', 'TM', 'Changlun', 'Kedah', 'North', 4566, 'Malaysia', 'peace@yahoo.com', '010', '0765436789'),
(5, 'hgdfghjkl', 'rtyuiopoiuyt', 'bdbfnmg', 'absdfngm', 'asdhfgbjnkhmjlk,j.h.sADFGHJK', 'agsdyfugihjop;,dmnsfghjk', 'pasdfogkhj', 'asdfghjk', 2345, 'Australia', 'asdfghg@uyfhngf.com', '014', '2345678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pID`);

--
-- Indexes for table `shipping_details`
--
ALTER TABLE `shipping_details`
  ADD PRIMARY KEY (`shpID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `orderID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `shipping_details`
--
ALTER TABLE `shipping_details`
  MODIFY `shpID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
