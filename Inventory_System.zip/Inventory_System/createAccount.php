
<!doctype html>
<html>
<head>

<title>SIGN-UP</title>

<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="signUp.css">
<link rel="stylesheet" type="text/css" href="style.css">


</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>
    </ul>
  </div>
</div>

<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>      
  </div>
</div>
</div>

<p>
<p>
<center>
<?php

$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");

	$fname = $_POST['fName'];
	$lname = $_POST['lName'];
	$pass = $_POST['pW'];
    $rePass = $_POST['pWW'];
    $hAdd = $_POST['hAdd'];
	$pAdd = $_POST['pAdd'];
	$city = $_POST['city'];
    $region = $_POST['region'];
    $zipCode = $_POST['zipCode'];
	$country = $_POST['ctry'];
    $email = $_POST['myEmail'];
    $pNum = $_POST['pNumber'];
    $mailList = $_POST['usertel'];


$sql = $connection->prepare("INSERT INTO users(id, firstName, lastName, password, rePassword, homeAddress, presentAddress, city, region, zipCode, Country, email, phoneNumber, mailList) VALUES ('','$fname', '$lname', '$pass', '$rePass', '$hAdd', '$pAdd', '$city', '$region', '$zipCode', '$country', '$email', '$pNum', '$mailList')");
  
   $sql->execute();

echo "<h1>Your Account has been Created!</h1>";

 
?>
</center>
</body>
</html>