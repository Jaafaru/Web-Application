
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="addProduct.html">Add New Product</a></li>
      <li><a href="editProduct.html">Edit a product</a></li>
      <li><a href="searchProduct.html">Search for a product</a></li>
      <li><a href="viewAllProduct.php">View All Products</a></li>
      <li><a href="deleteProduct.html">Delete Product</a></li>

    </ul>
  </div>
</div>
<div id = "container">
  <div id = "logo">
    <img id = "brief-text" src="images/logo.jpg" align = "left"> 

   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>    
  </div>
</div>
</div>
<center>
<?php
$connection = new PDO("mysql:host=localhost; dbname=online_shopping", "root", "");

$pID = $_POST["sProduct"];
// execute SQL SELECT query
$sql = $connection->query("SELECT * FROM product where pID = '$pID'");
$no=$sql->rowCount();   // number of rows affected by the last SQL statement  

if ($no == 0)
 {echo "RECORD NOT FOUND";}
else
{	// number of returned columns
	//$cols = $sql->columnCount();  // returns number of column in the result set
	//echo 'Number of returned columns: ' . $cols. '<br>';
	// Parse the result set & extract specific fields
	foreach($sql as $row)
	{
	   $pID = $row['pID'];
	   $pType= $row['pType'];
	   $pName = $row['pName'];
	   $pSize = $row['pSize'];
	   $pPrice= $row['pPrice'];
	   $pDesc= $row['pDesc'];
?> 

 <form action="updateProduct.php" method="post" enctype="multipart/form-data" class="form-horizontal">
  <table>
     <tr>
       <td colspan="3" align="center"><h1><strong>Edit a Product</strong></h1></td>
     </tr>
     <tr>
       <td>
        <label class="control-label">Product ID:</label></td>
       <td>
        <input type="text" name="prodID" readonly value="<?php echo "$pID"; ?>">
       </td>
     </tr>
     <tr>
       <td>
       <label class="control-label">Product Type:</label> 
       </td>
       <td>
        <input type="text" name="prodType" readonly value="<?php echo "$pType"; ?>">
       </td>
     </tr>
     <tr>
       <td>
        <label class="control-label">Product Name:</label> 
       </td>
       <td>
        <input type="text" name="prodName" readonly value="<?php echo "$pName"; ?>">
       </td>
     </tr>
     <tr>
       <td>
       <label class="control-label">Product Size:</label> 
       </td>
       <td>
        <input type="text" name="prodSize">
       </td>
     </tr>
     <tr>
       <td>
        <label class="control-label">Product Price:</label> 
 
       </td>
       <td>
        <input type="text" name="prodPrice">
       </td>
     </tr>
     <tr>
       <td>
        <label class="control-label">Product Image:</label> 
       </td>
       <td>
        <input type="file" name="prodImage" accept="image/*">
       </td>
     </tr>
     <tr>
       <td>
       <label class="control-label"> Product Description:</label> 
       </td>
       <td>
        <textarea name="prodDesc">
        </textarea>
       </td>
     </tr>
     <tr>
       <td colspan="2" align="center">
        <input type="submit" name="updateData" value="Update Product">
       </td>
     </tr>
  
  </table> 
</form>
    <?php
       }
       }
       ?> 
</center> 
</body>
</html>