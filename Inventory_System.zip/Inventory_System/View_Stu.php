<?php
$connection = new PDO("mysql:host=localhost; dbname=isaa", "root", "");

$sql = $connection->query("SELECT * FROM student");
$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}
else
	// number of returned columns
	//$cols = $sql->columnCount();  // returns number of column in the result set
	//echo 'Number of returned columns: ' . $cols. '<br>';
	// Parse the result set & extract specific fields
	?> 
<table border="1" style="width:80%" align="center" cellpadding="5">
<tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Other Name(s)</th>
    <th>Email</th>
    <th>Gender</th>
    <th>Phone No.</th> 
    <th>Race</th> 

</tr>
<?php
	foreach($sql as $row)
	{
	   $id = $row['id'];
	   $Fname= $row['Fname'];
	   $Oname = $row['Oname'];
	   $email = $row['email'];
	   $Gender= $row['Gender'];  
	   $phone = $row['phone']; 
	   $race = $row['race']; 

	   echo 
	"<tr>
	<td>$id</td>
    <td>$pFname</td>
    <td>$Oname</td>
    <td>$email</td>
    <td>$Gender</td>
	<td>$phone</td>
	<td>$race</td>";
    }
    echo "</tr>\n";
	echo '</table>';
?>