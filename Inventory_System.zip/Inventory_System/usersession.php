<?php
$email = $_GET['email']; 
session_start(); 
$_SESSION['email'] = $email; 

if(isset($_SESSION['email'])){ 
  header("Location: product.php");
  
} else { 
echo " 
<script language='javascript'> 
alert('Sorry, You must login to purchase a product!')
</script> 
<script> 
window.location='signIn.php'
</script> 
"; } 
?>