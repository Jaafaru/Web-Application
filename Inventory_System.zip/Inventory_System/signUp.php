<!doctype html>
<html>
<head>

<title>SIGN-UP</title>

<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="signUp.css">
<link rel="stylesheet" type="text/css" href="style.css">


</head>

<body bgcolor="#CCCCCC">

<div id = "loginHeader">
    <a href="adminSignIn.php">Admin Login</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="signout.php"><img src="images/checkOut.JPG">Sign out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.php" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.php">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="userPage.php">Products</a>
      <li><a href="contactUs.php">Contact Us</a></li>
    </ul>
  </div>
</div>

<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>      
  </div>
</div>
</div>

<p>
<p>
<center>
<h1>Create your account</h1>
<form name="myForm" method="post" action="createAccount.php"><br>
<table class="table1">
	<tr>
    	<td>Full Name:</td><td><input type="text" name="fName"> <input type="text" name="lName" required><br>First Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Last Name</td>
    
    </tr>
    <tr>
    	<td>Password:</td><td><input type="password" name="pW"></td>
    </tr>
    <tr>
    	<td>Re-enter Password:</td><td><input type="password" name="pWW"></td>
    </tr>
    <tr>
    	<td>Address:</td><td><input type="text" name="hAdd" size="70" required><br>Home Address</td>
    </tr>
    
    <tr>
    	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td><input type="text" name="pAdd" size="70"><br>Present Address</td>
    
    </tr>
    
    <tr>
    	<td></td><td><input type="text" name="city">&nbsp;
        <input type="text" name="region"><br>City &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Region</td>
    
    </tr>
    
    <tr>
    	<td></td><td><input type="text" name="zipCode"> &nbsp;&nbsp;&nbsp;<select name="ctry">
  <option value="Please Select...">Please Select</option>
  <option value="Australia">Australia</option>
  <option value="Malaysia">Malaysia</option>
  <option value="Nigeria">Nigeria</option>
  <option value="Singapor">Singapore</option>
  <option value="China">China</option>
</select><br>Zip Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Country</td>
    
    </tr>
    
    <tr>
    	<td>Email:</td><td> <input type="email" name="myEmail" placeholder="ex:myname@example.com" size="30"></td>
    
    </tr>
    
    <tr>
    	<td>Phone Number</td><td><select name="pNumber">
  <option value="  ">  </option>
  <option value="010">010</option>
  <option value="011">011</option>
  <option value="012">012</option>
  <option value="013">013</option>
  <option value="014">014</option>
  <option value="015">015</option>
  <option value="016">016</option>
  <option value="017">017</option>
  <option value="018">018</option>
  <option value="019">019</option>
  </select> - <input type="tel" name="usertel" size="10"><br></td>
        
    </tr>
    
 <tr>
    <td colspan="3" align="center"><input type="submit" value = "Create Account " name="createaccount"><br><br></td>
 </tr>
</table>
</center>
</body>
</html>