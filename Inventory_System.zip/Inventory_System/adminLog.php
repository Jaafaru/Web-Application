<?php
session_start();
unset($_SESSION["aName"]);
unset($_SESSION["aPass"]);

header("Location: homepage.php");
?> 
