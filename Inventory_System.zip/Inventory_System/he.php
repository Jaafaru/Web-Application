<div id = "loginHeader">
    <a href="#">Language</a> 
    <a href="#">Currency RM</a> 
    <a href="signIn.php"><img src="images/signIn.png">Sign in</a> 
    <a href="#"><img src="images/myAccount.jpg">My Account</a>
    <a href="#"><img src="images/checkOut.JPG">Check out</a></div>
<div id = "top">
  <div id = "search-bar" class = "search" align="center">
      <form action="homepage.html" >
      <input type="text" name = "Search" placeholder="Enter a keyword search..." size="150%" border="1" height="100px" >
      <input type="Submit" value = "Search">
    </form>
  </div>
  <div id = "nav-bar">
    <ul id = "nav">
      <li><a href="homepage.html">Home</a></li>
      <li><a href="aboutUs.php">About Us</a></li>
      <li><a href="#">Products<span class="arrow">&#9660;</span></a>
      <li><a href="contactUs.php">Contact Us</a></li>
      <li><a href="#">Administrator</a></li>

    </ul>
  </div>
</div>

<div id = "container">
  <div id = "logo">
  <img id = "brief-text" src="images/logo.jpg" align = "left"> 
   <p style="font-weight:300" align="center"><em><strong>  PS Electronic Online website enables users order gadgets online. It is an open framework for all users to order gadgets online through the Internet system. This likewise gives customers negligible time and procedures for purchasing their sought gadgets with an assortment of choices.
   </strong></em></p>  