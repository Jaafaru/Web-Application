<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);

$error = false;

  if ( isset($_POST['btn-addreport']) ) {
    
    // clean user inputs to prevent sql injections
    $date = trim($_POST['date']);
    $date = strip_tags($date);
    $date = htmlspecialchars($date);
    
    $report = trim($_POST['report']);
    $report = strip_tags($report);
    $report = htmlspecialchars($report);

    // basic name validation
    if (empty($date)) {
      $error = true;
      $dateError = "Please enter Date.";
    } else if (empty($report)) {
      $error = true;
      $reportError = "Please enter report.";
    } 
    
    // if there's no error, continue to add report
    if( !$error ) {
      
      $query = "INSERT INTO weekly_report(Rdate,report) 
      VALUES('$date','$report')";
      $res = mysql_query($query);
        
      if ($res) {
        $errTyp = "success";
        $errMSG = "Successfully Added Report";
        unset($date);
        unset($report);
      } else {
        $errTyp = "danger";
        $errMSG = "Something went wrong, try again later..."; 
      } 
        
    }
  
    
  }

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['userEmail']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="home.php" >UUMPS</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="home.php">Home</a></li>
            <li class="active"><a href="add_weekly_report.php">Add Weekly Report</a></li>
            <li ><a href="student_view_weekly_report.php">View Weekly Report</a></li>
            
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userName']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
              	<li><a href="profile_student.php?profile_student"><span class="glyphicon glyphicon-edit"></span>&nbsp;My Profile</a></li>
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div class="container">
    
    	<div class="page-header">
    	<h3><marquee>Welcome to Universiti Utara Malaysia Practicum System</marquee></h3>
    	</div>
        
        <div class="row">
        <div class="col-lg-12">
        <h1>
        </div>
        </div>

        <div class ="row">
          <div id="login-form">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
    
      <div class="col-md-12">
        
          <div class="form-group">
              <h2 class="">Weekly Report</h2>
            </div>
        
          <div class="form-group">
              <hr />
            </div>
            
            <?php
      if ( isset($errMSG) ) {
        
        ?>
        <div class="form-group">
              <div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
        <span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
              </div>
         <?php
      }
      ?>

          <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
              <input type="date" name="date" class="form-control" placeholder="Enter Name" maxlength="50" />
                </div>
                <span class="text-danger"><?php echo $dateError; ?></span>
            </div>
            
            
           <div class="form-group">
             <div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-comment"></span></span>
              <textarea class="form-control" rows="5" name="report"></textarea>
              </div>
              <span class="text-danger"><?php echo $reportError; ?></span>
            </div>
            <div class="form-group">
              <hr />
            </div>
            
            <div class="form-group">
              <button type="submit" class="btn btn-block btn-primary" name="btn-addreport">Add Report</button>
            </div>
            
            <div class="form-group">
              <hr />
            </div>
            
            
        </div>
   
    </form>
    </div>


        </div>


    
    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>