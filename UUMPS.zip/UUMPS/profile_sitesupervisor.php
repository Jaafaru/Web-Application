<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM sitesupervisor WHERE sitesupervisorId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);

	$error = false;

	
	if ( isset($_POST['btn-update']) ) {
		
		// clean user inputs to prevent sql injections
		$updname = trim($_POST['updname']);
		$updname = strip_tags($updname);
		$updname = htmlspecialchars($updname);
		
		
		$updpass = trim($_POST['updpass']);
		$updpass = strip_tags($updpass);
		$updpass = htmlspecialchars($updpass);

		$updcompany = trim($_POST['updcompany']);
		$updcompany = strip_tags($updcompany);
		$updcompany = htmlspecialchars($updcompany);


		// basic name validation
		if (empty($updname)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($updname) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		} else if (!preg_match("/^[a-zA-Z ]+$/",$updname)) {
			$error = true;
			$nameError = "Name must contain alphabets and space.";
		} else if (empty($updcompany)) {
      $error = true;
      $matricError = "Please enter Company.";
    } 
		
		
		// password validation
		if (empty($updpass)){
			$error = true;
			$passError = "Please enter password.";
		} else if(strlen($updpass) < 6) {
			$error = true;
			$passError = "Password must have atleast 6 characters.";
		}
		
		// password encrypt using SHA256();
		//$password = hash('sha256', $updpass);
		
		// if there's no error, continue to signup
		if( !$error ) {


			$query = " UPDATE sitesupervisor SET name='$updname', sitepass='$updpass', company='$updcompany' WHERE sitesupervisorId=".$_SESSION['user'];
			$res = mysql_query($query);
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully Updated";
				
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
				
		}
	}

?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="home_uumsupervisor.php" >UUMPS</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="home_sitesupervisor.php">Home</a></li>
            <li><a href="site_view_weekly_report.php">View Weekly Report</a></li>
            <li><a href="site_evaluate.php">Evaluate</a></li>
            <li><a href="site_view_evaluation.php">Veiw Evaluate</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['name']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
              	<li><a href="profile_sitesupervisor.php?profile_sitesupervisor"><span class="glyphicon glyphicon-edit"></span>&nbsp;My Profile</a></li>
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div class="container">
    
    	
        <div class="row">
        <div class="col-lg-12">
        <h1>
        </div>
        </div>
        <div class ="row">
          <table class="table table-striped table-bordered table-hover" id="dataTables-example">
             <thead>
           <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Company</th>
                                       </tr>
                                   </thead>

          <?php 

          $sql="SELECT * FROM sitesupervisor"; 
          //-run  the query against the mysql query function 
      $result=mysql_query($sql) or die ("invalid SQL query".mysql_error()); 

        ?>

              <?php  
          //$sql = "SELECT * FROM Reports"; 
          //$result = mysql_query($sql) or die ("invalid SQL query ".mysql_error());

              

          while($row = mysql_fetch_array($result))
          {
             $id = $row['sitesupervisorId'];
             $name =$row['name'] ;
             $email = $row['email'];
             $company= $row['company'];
             $pass = $row['sitepass'] ;
             
          ?>

          <tbody>
                    <tr class="odd gradeX">
                    <td><?php echo "".$id ?></a></td>
                    <td><?php echo "".$name?></td>
                    <td><?php echo "".$email ?></td>
                    <td><?php echo "".$company ?></td>  
                        
   </tr>
                 </tbody>
    
          <?php 
          } 
          ?>
                    
          </table>


        </div>

<div id="login-form">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
    
      <div class="col-md-12">
        
          <div class="form-group">
              <h2 class="">Update Your Profile.</h2>
            </div>
        
          <div class="form-group">
              <hr />
            </div>
            
            <?php
      if ( isset($errMSG) ) {
        
        ?>
        <div class="form-group">
              <div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
        <span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
              </div>
                <?php
      }
      ?>
            
            <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
              <input type="text" name="updname" class="form-control" placeholder="Enter Name" maxlength="50" value="<?php echo $name ?>" />
                </div>
                <span class="text-danger"><?php echo $nameError; ?></span>
            </div>
            
            <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
              <input type="email" name="updemail" class="form-control" placeholder="Enter Your Email" maxlength="40" value="<?php echo $email ?>" />
                </div>
                </div>
            
            <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
              <input type="password" name="updpass" class="form-control" placeholder="Enter Password" maxlength="15" value="<?php echo $pass ?>" />
                </div>
                <span class="text-danger"><?php echo $passError; ?></span>
            </div>

           <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-edit"></span></span>
              <input type="text" name="updcompany" class="form-control" placeholder="Enter Your Company" maxlength="40" value="<?php echo $company ?>"/>
                </div>
                <span class="text-danger"><?php echo $companyError; ?></span>
            </div>

  
            
            <div class="form-group">
              <hr />
            </div>
            
            <div class="form-group">
              <button type="submit" class="btn btn-block btn-primary" name="btn-update">Update</button>
            </div>
            
            <div class="form-group">
              <hr />
            </div>
            
            
        </div>
   
    </form>
    </div>

    
    </div>
    
    </div>
    

    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>