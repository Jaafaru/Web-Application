<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM college WHERE collegeId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);

  if ( isset($_POST['btn-update']) ) {
    
    // clean user inputs to prevent sql injections    
    $upddate = trim($_POST['upddate']);
    $upddate = strip_tags($upddate);
    $upddate = htmlspecialchars($upddate);
    
    $updannouncement = trim($_POST['updannouncement']);
    $updannouncement = strip_tags($updannouncement);
    $updannouncement = htmlspecialchars($updannouncement);


    // basic name validation
    if (empty($upddate)) {
      $error = true;
      $dateError = "Please enter date.";
    }else if (empty($updannouncement)) {
      $error = true;
      $announcementError = "Please enter announcement.";
    } 
    
    
    // if there's no error, continue to signup
    if( !$error ) {


      $query = " INSERT INTO announcement(annDate,announcement) 
      VALUES('$upddate','$updannouncement')";
      $res = mysql_query($query);
        
      if ($res) {
        $errTyp = "success";
        $errMSG = "Successfully Added announcement";
        
      } else {
        $errTyp = "danger";
        $errMSG = "Something went wrong, try again later..."; 
      } 
        
    }
  }

   if ( isset($_POST['btn-delete']) ) {
    
    // clean user inputs to prevent sql injections    
    $updid = trim($_POST['updid']);
    $updid = strip_tags($updid);
    $updid = htmlspecialchars($updid);


    // basic name validation
    if (empty($updid)) {
      $error = true;
      $idError = "Please enter ID.";
    }
    
    
    // if there's no error, continue to signup
    if( !$error ) {


      $query = "DELETE FROM announcement WHERE id=$updid";
      $res = mysql_query($query);
        
      if ($res) {
        $errTyp = "success";
        $errMSG = "Successfully Delete announcement";
        
      } else {
        $errTyp = "danger";
        $errMSG = "Something went wrong, try again later..."; 
      } 
        
    }
  }

  
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $userRow['email']; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="home_college.php">UUMPS</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li ><a href="home_college.php">Home</a></li>
            <li ><a href="view_uum_evaluation.php">View Report</a></li>
            <li><a href="">Assign Supervisor</a></li>
            <li class="active"><a href="add_announcement.php"> Announcement</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['name']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="profile_college.php?profile_college"><span class="glyphicon glyphicon-edit"></span>&nbsp;My Profile</a></li>
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div class="container">
    
    	<div class="page-header">
    	<h3><marquee>Welcome to Universiti Utara Malaysia Practicum System</marquee></h3>
    	</div>
        
        <div class="row">
        <div class="col-lg-12">
        <h1>
        </div>
        </div>

        <div class ="row">
          <table class="table table-striped table-bordered table-hover" id="dataTables-example">
             <thead>
           <tr>
                  <th>ID</th>
                  <th>Date</th>
                  <th>Announment</th>
                  
                                       </tr>
                                   </thead>

          <?php 

          $sql="SELECT * FROM announcement"; 
          //-run  the query against the mysql query function 
      $result=mysql_query($sql) or die ("invalid SQL query".mysql_error()); 

        ?>

              <?php  
          //$sql = "SELECT * FROM Reports"; 
          //$result = mysql_query($sql) or die ("invalid SQL query ".mysql_error());

          while($row = mysql_fetch_array($result))
          {
             $id = $row['id'];
             $Adate = $row['annDate'];
             $name =$row['announcement'] ;
             

          ?>

          <tbody>
                    <tr class="odd gradeX">
                    <td><?php echo "".$id ?></a></td>
                    <td><?php echo "".$Adate?></td>
                    <td><?php echo "".$name?></td>
                           
   </tr>
                 </tbody>
    
          <?php 
          } 
          ?>
                    
          </table>


        </div>
        

<div id="login-form">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
    
      <div class="col-md-12">
        
          
          
            
            <?php
      if ( isset($errMSG) ) {
        
        ?>
        <div class="form-group">
              <div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
        <span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
              </div>
                <?php
      }
      ?>
            
            <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
              <input type="Date" name="upddate" class="form-control" placeholder="Enter the date" maxlength="15"  />
                </div>
                <span class="text-danger"><?php echo $dateError; ?></span>
            </div>

           <div class="form-group">
             <div class="input-group">
              <span class="input-group-addon"><span class="glyphicon glyphicon-comment"></span></span>
              <textarea class="form-control" rows="5" name="updannouncement" value="">Comment...</textarea>
              </div>
              <span class="text-danger"><?php echo $announcementError; ?></span>
            </div>

  
            
            <div class="form-group">
              <hr />
            </div>
            
            <div class="form-group">
              <button type="submit" class="btn btn-block btn-primary" name="btn-update">Add Announcement</button>

              <div class="form-group">
              <hr />
            </div>
              <div class="form-group">
              <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-edit"></span></span>
              <input type="text" name="updid" class="form-control" placeholder="Enter the Id of the announcement" maxlength="15"  />
                </div>
                <span class="text-danger"><?php echo $idError; ?></span>
            </div>
              <button type="submit" class="btn btn-block btn-danger" name="btn-delete">Delete Announcement</button>
            </div>
            
            <div class="form-group">
              <hr />
            </div>
            
            
        </div>
   
    </form>
    </div>


    
    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>