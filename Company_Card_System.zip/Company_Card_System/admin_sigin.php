<?php include('sess.php');
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
if (isset($_POST['sub'])){

	$pass1 = $_POST['pass1'];
     
	$staff_id = $_POST['staff_id'];
	if (($pass1 =='admin') && ($staff_id='admin')){
		$_SESSION['admin'] = $staff_id;
	header("location: adminpage.php");
			}else{
				$msg =  "Your username or password is invalid";}

			 
			 

	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />

</div><br />
<hr />
<center>
<h2 align="center">Sign In to Kanban Card System</h2>
<hr />
<form action="" method="post">
<table border="0" cellspacing="10" cellpadding="10">
  <tr>
    <td>Admin Name</td>
    <td><span id="sprytextfield2">
      <label for="staff_id"></label>
      <input type="text" name="staff_id" id="staff_id" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><span id="sprypassword1">
      <label for="pass1"></label>
      <input type="password" name="pass1" id="pass1" />
      <span class="passwordRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td  align="center" colspan="2"><?php if(isset($msg)) echo $msg; ?></td>
    
  </tr><tr>
    <td  align="center" colspan="2"><input type="submit" name="sub" id="sub" value="Submit" />||<input name="" type="reset" value="Clear Form" /></td>   
  </tr>
  <tr>
   <td align="center" colspan="2"></td>
  </tr>
</table>
</form>
<script type="text/javascript">
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {hint:"Enter number"});
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
</script>
</center>
</body>
</html>