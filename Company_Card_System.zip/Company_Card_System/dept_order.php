<?php include('sess.php');
if(!isset($_SESSION['admin']) ) header("Location: index.php");
if(!isset($_GET['id']) ) header("Location: adminpage.php");
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Line Order History</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="adminpage.php">Home</a></li>
  <li><a href="search_card.php">Search Card</a></li>
  <li><a href="search_person.php">Search Staff</a></li>
  <li><a href="view_order_details.php">View All Orders</a></li>
<li><a href="view_order_history.php">View Staff History</a></li>
<li><a href="view_order_history_dept.php">View Line History</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center">Admin Logged In</h2>
<hr />
<h2 align="center">View Ordered History For People In a Line</h2>
<hr />


<?php
$id = $_GET['id'];

$sql = $connection->query("select s.staff_id as i, s.name as n, c.card_no as no, c.order_date as d,c.order_time as t, c.card_purpose as cp from card_orders c, staff s where s.department = '$id' and s.staff_id=c.staff_id");

$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}else{
	
echo '<p align="center"> '.$id.'  have ordered a total of '.$no.' cards </p>
<table   align="center" cellpadding="5" cellspacing="5">
<tr>
    <th>Staff Number</th>
	<th>Staff Name</th>
	<th>Date</th>
    <th>Time</th>
    <th>Card Number</th>
    <th>Card Purpose</th>

</tr>';

	foreach($sql as $row)
	{
		$i = $row['i'];
	   $n = $row['n'];
	   $d = $row['d'];
	   $t = $row['t'];
	   $c = $row['no'];
	  $cp = $row['cp']; 

	   echo 
	"<tr>
	<td><a href=staff_order.php?id=$i>$i</a></td>
	<td>$n</td>	
	<td>$d</td>
    <td>$t</td>
    <td>$c</td>
    <td>$cp</td>";
	}
    echo "</tr>\n";
	echo '</table>';
	}
?>
</body>
</html>

