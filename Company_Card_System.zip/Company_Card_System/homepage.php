<?php 
session_start();
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
if(isset($_SESSION['staff_id']))
{

	$email = $_SESSION['staff_id']
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="staff.css" />
</head>

<body>
<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="homepage.php">Home</a></li>
 <li><a href="card_order_details.php">Order Card</a></li>
  <li><a href="view_history.php">View History</a></li>
  <li><a href="my_details.php">My Details</a></li>
 
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center"><?php echo 'Staff '.$_SESSION['staff_id'].' Logged in'; ?></h2>
<hr />

</body>
</html>

<?php	
}
else
{
	?>
    <script>alert('Please login to view this page');</script>
    <?php
	header("Location: index.php");
}
?>