<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome</title>
<link rel="stylesheet" type="text/css" href="index.css" />
</head>


<body>
<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">

  <li><a href="signin.php">Staff Sign In</a></li>
  <li><a href="admin_sigin.php">Admin Sign In</a></li>
   
</ul>  	
</div> 
 </body>
</html>