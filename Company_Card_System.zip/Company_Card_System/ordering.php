<?php include('sess.php');
if(!isset($_SESSION['staff_id'])) header("Location: index.php");
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="staff.css"  />
</head>

<body>
<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="homepage.php">Home</a></li>
 <li><a href="card_order_details.php">Order Card</a></li>
  <li><a href="view_history.php">View History</a></li>
  <li><a href="my_details.php">My Details</a></li>
 
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center"><?php echo 'Staff '.$_SESSION['staff_id'].' Logged in'; ?></h2>
<hr />
  <center>
  <?php 

$len = count($_POST['voucher']);
echo $len; 
$id = $_SESSION['staff_id'];
for($i=0;$i<$len;$i++){
	
	//echo $_POST['voucher'][$i];
	//echo $_POST['pur'][$i];
	$v = $_POST['voucher'][$i];
	$p =  $_POST['pur'][$i];	
	
$sql = $connection->prepare("INSERT INTO card_orders( staff_id, card_no, order_date, order_time, card_purpose) VALUES ('$id','$v', NOW(), NOW(), '$p')");
  
  $sql->execute();
	
	}
	echo $len .' records inserted';
?>
 </center>
</body>
</html>
