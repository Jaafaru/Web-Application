<?php include('sess.php');
if(!isset($_SESSION['staff_id'])) header("Location: index.php");
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="staff.css" />
</head>

<body>
<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="homepage.php">Home</a></li>
 <li><a href="card_order_details.php">Order Card</a></li>
  <li><a href="view_history.php">View History</a></li>
  <li><a href="my_details.php">My Details</a></li>
 
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center"><?php echo 'Staff '.$_SESSION['staff_id'].' Logged in'; ?></h2>
<hr />
<br />
<h1 align="center">Card Order </h1>
<hr />
<center>
<form action="" method="post">
<table border="0" cellspacing="10" cellpadding="10">
  <tr>
    <td>Quantity</td>
    <td><span id="sprytextfield3">
      <label for="qty"></label>
      <input type="text" name="qty" id="qty" />
      <span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span></td>
  </tr>
  
  <tr>
    <td  align="center" colspan="2"><?php if(isset($msg)) echo $msg; ?></td>
    
  </tr><tr>
    <td  align="center" colspan="2"><input type="submit" name="sub" id="sub" value="Submit" />||<input name="" type="reset" value="Clear Form" /></td>
    
  </tr>
</table>
</form>
</center>


<?php
if (isset($_POST['sub'])){

	$qty = $_POST['qty'];
	
	echo '<form action="ordering.php" method="post">
<table border="0" cellspacing="10" cellpadding="10" align="center">
 <tr>
		<td> S/N </td>
		<td> Card Number </td>
		<td> Card Purpose </td></tr>';
		$j = 1;
  
     for($i=0;$i<$qty;$i++){
		 $n = $j++;
		echo '<tr>
		<td> '.$n.'  
		<td> <input type="textbox" name="voucher[]"> 
		<td> <input type="textbox" name="pur[]"></td></tr>'; 
		 
		 }
		 echo '<tr><td  align="center" colspan="2"><input type="submit" name="sub" id="sub" value="Submit" /></td></tr></table></form>';
	 
 			 

	}
?>
<script type="text/javascript">

var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "integer");
</script>
</body>
</html>
