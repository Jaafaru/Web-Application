<?php include('sess.php');
if(!isset($_SESSION['staff_id'])) header("Location: index.php");
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
$id = $_SESSION['staff_id'];
 
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="staff.css" />
</head>

<body>

<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="homepage.php">Home</a></li>
 <li><a href="card_order_details.php">Order Card</a></li>
  <li><a href="view_history.php">View History</a></li>
  <li><a href="my_details.php">My Details</a></li>
 
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center"><?php echo 'Staff '.$_SESSION['staff_id'].' Logged in'; ?></h2>
<hr /><h2 align="center">My Details</h2>
<hr />


<?php

$sql = $connection->query("select count(c.staff_id) as num, s.name as n, s.staff_id as i, s.phone as p,s.email as e, s.department as d from card_orders c, staff s where s.staff_id = c.staff_id and s.staff_id ='$id' group by (c.staff_id)");

$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}else{
	
echo '
<table   align="center" cellpadding="5" cellspacing="5">
<tr>

    <th>Number ordered by staff</th>
	<th>Staff Number</th>
	<th>Staff Name</th>
	<th>Staff Department</th>
	<th>Staff Phone</th>
	<th>Staff Email</th>
	 
</tr>';

	foreach($sql as $row)
	{
	   $num = $row['num'];
	   $i = $row['i'];
	   $n = $row['n'];
	   $d = $row['d'];
	   $p = $row['p'];
	   $e = $row['e'];
	   

	   echo 
	"<tr>
	<td>$num</td>
	<td>$i</td>
    <td>$n</td>
    <td>$d</td> 
	<td>$p</td> 
	<td>$e</td> ";
	}
    echo "</tr>\n";
	echo '</table>';
	}
?>
</body>
</html>


