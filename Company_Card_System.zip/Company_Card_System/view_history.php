<?php 
include('sess.php');
if(!isset($_SESSION['staff_id'])) header("Location: index.php");
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
$id = $_SESSION['staff_id'];
 
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="staff.css" />
</head>

<body>

<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="homepage.php">Home</a></li>
 <li><a href="card_order_details.php">Order Card</a></li>
  <li><a href="view_history.php">View History</a></li>
  <li><a href="my_details.php">My Details</a></li>
 
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center"><?php echo 'Staff '.$_SESSION['staff_id'].' Logged in'; ?></h2>
<hr /><h2 align="center">View Previous Orders</h2>
<hr />
 
<?php 

$sql = $connection->query("select * from card_orders where staff_id = '$id'");

$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}else{
	
echo '<p align="center"> You have ordered a total of '.$no.' cards </p>
<table   align="center" cellpadding="5" cellspacing="5">
<tr>
    <th>Date</th>
    <th>Time</th>
    <th>Card Number</th>
    <th>Card Purpose</th>

</tr>';

	foreach($sql as $row)
	{
	   $d = $row['order_date'];
	   $t = $row['order_time'];
	   $c = $row['card_no'];
	  $cp = $row['card_purpose']; 

	   echo 
	"<tr>
	<td>$d</td>
    <td>$t</td>
    <td>$c</td>
    <td>$cp</td>";
	}
    echo "</tr>\n";
	echo '</table>';
	}
?>


</body>
</html>
