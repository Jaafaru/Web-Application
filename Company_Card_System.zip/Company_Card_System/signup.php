<?php
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
if (isset($_POST['sub'])){
	
	$name = $_POST['name'];
	
	$pass1 = $_POST['pass1'];
    $line = $_POST['dept'];
    $phone = $_POST['phone'];
	$email = $_POST['email'];
	$staff_id = $_POST['staff_id'];
	 


$sql = $connection->prepare("INSERT INTO staff( staff_id, name, department, phone, email, pass) VALUES ('$staff_id','$name', '$line', '$phone', '$email', '$pass1')");
  
  if ($sql->execute()) {
	
	header("Location: index.php");
}else{echo 'error';}
 
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationConfirm.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationConfirm.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />
<h2 align="center">Sign Up for Kanban Card System</h2>
<hr />
<center>
<form action="" method="post">
<table border="0" cellspacing="10" cellpadding="10">
  <tr>
    <td>Name</td>
    <td><span id="sprytextfield1">
      <label for="name"></label>
      <input type="text" name="name" id="name" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td>Staff ID</td>
    <td><span id="sprytextfield2">
    <label for="staff_id"></label>
    <input type="text" name="staff_id" id="staff_id" />
    <span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span></td>
  </tr>
  <tr>
    <td>Line</td>
    <td><span id="spryselect1">
      <label for="dept"></label>
      <select name="dept" id="dept">
        <option>.::Select::.</option>
        <option value="Line1">Line 1</option>
        <option value="Line2">Line 2</option>
        <option value="Line3">Line 3</option>
      </select>
      <span class="selectRequiredMsg">Please select an item.</span></span></td>
  </tr>
  <tr>
    <td>Phone number</td>
    <td><span id="sprytextfield3">
    <label for="phone"></label>
    <input type="text" name="phone" id="phone" />
    <span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span></td>
  </tr>
  <tr>
    <td>Email</td>
    <td><span id="sprytextfield4">
    <label for="email"></label>
    <input type="text" name="email" id="email" />
    <span class="textfieldRequiredMsg">A value is required.</span><span class="textfieldInvalidFormatMsg">Invalid format.</span></span></td>
  </tr>
  <tr>
    <td>Password</td>
    <td><span id="sprypassword1">
      <label for="pass1"></label>
      <input type="password" name="pass1" id="pass1" />
      <span class="passwordRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td>Re-enter Password</td>
    <td><span id="spryconfirm1">
      <label for="pass2"></label>
      <input type="password" name="pass2" id="pass2" />
      <span class="confirmRequiredMsg">A value is required.</span><span class="confirmInvalidMsg">The values don't match.</span></span></td>
  </tr>
  <tr>
    <td  align="center" colspan="2"><input type="submit" name="sub" id="sub" value="Submit" />||<input name="" type="reset" value="Clear Form" /></td>
     
  </tr>
</table>
</form>
</center>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "integer", {useCharacterMasking:true, hint:"Enter number"});
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "integer", {useCharacterMasking:true});
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "email", {hint:"abc@ede.com"});
var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
var spryconfirm1 = new Spry.Widget.ValidationConfirm("spryconfirm1", "pass1");
</script>
</body>
</html>