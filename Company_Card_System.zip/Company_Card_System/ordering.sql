-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2017 at 09:14 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ordering`
--
CREATE DATABASE IF NOT EXISTS `ordering` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ordering`;

-- --------------------------------------------------------

--
-- Table structure for table `card_orders`
--

CREATE TABLE `card_orders` (
  `order_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `card_no` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_time` time NOT NULL,
  `card_purpose` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card_orders`
--

INSERT INTO `card_orders` (`order_id`, `staff_id`, `card_no`, `order_date`, `order_time`, `card_purpose`) VALUES
(1, 234, 123, '2017-02-19', '03:42:28', 'jhgbhjj'),
(2, 234, 234, '2017-02-19', '03:42:28', 'lkonkl'),
(3, 1234, 125, '2017-02-19', '08:53:46', 'gyhhh'),
(4, 234, 1234, '2017-02-19', '16:12:34', 'abc'),
(5, 234, 14, '2017-02-19', '16:12:34', 'frg'),
(6, 234, 56, '2017-02-19', '16:12:34', 'ui'),
(7, 234, 245, '2017-02-19', '16:12:34', 'yyu'),
(8, 1234, 4567, '2017-02-19', '16:44:16', 'Car product'),
(9, 1234, 4567, '2017-02-19', '16:44:55', 'Car product');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(11) NOT NULL,
  `pass` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `email`, `phone`, `pass`) VALUES
(1, 1234, 'sem', 'Line2', 'abc@ede.com', 12345, 't123'),
(2, 234, 'wer', 'Line2', 'abc@ede.com', 1234, '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `card_orders`
--
ALTER TABLE `card_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `staff_id` (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `card_orders`
--
ALTER TABLE `card_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
