<?php include('sess.php');
if(!isset($_SESSION['admin'])) header("Location: index.php");
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
$id = $_SESSION['admin'];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View Ordered History By Line</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />
</div><br />
<hr />

<div id = "bar">
  <ul id= "nav">
  <li><a href="adminpage.php">Home</a></li>
  <li><a href="search_card.php">Search Card</a></li>
  <li><a href="search_person.php">Search Staff</a></li>
  <li><a href="view_order_details.php">View All Orders</a></li>
<li><a href="view_order_history.php">View Staff History</a></li>
<li><a href="view_order_history_dept.php">View Line History</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center">Admin Logged In</h2>
<hr />
<hr />
<h2 align="center">View Line Order History</h2>
<hr />
<?php

$sql = $connection->query("select count(s.department) as num, s.department as d from card_orders c, staff s where s.staff_id = c.staff_id group by (s.department)");

$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}else{
	
echo '<p align="center"> Number of cards ordered by each line  </p>
<table   align="center" cellpadding="5" cellspacing="5">
<tr>

    <th>Number ordered by Line</th>
	<th>Line</th>
	 
</tr>';

	foreach($sql as $row)
	{
	   $num = $row['num'];
	   $d = $row['d'];
	   

	   echo 
	"<tr>
	<td><a href=dept_order.php?id=$d>$num</a></td>
	<td>$d</td> ";
	}
    echo "</tr>\n";
	echo '</table>';
	}
?>
</body>
</html>

