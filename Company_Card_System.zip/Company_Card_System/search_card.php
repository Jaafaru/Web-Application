<?php include('sess.php');
$connection = new PDO("mysql:host=localhost; dbname=ordering", "root", "");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Search By Card</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<h1 align="center">KANBAN CARD SYSTEM</h1>
<div id="logo">
	<img id="img_logo" src="b_logo.jpg" width="1255px" height="180px" />

</div><br />
<div id = "bar">
  <ul id= "nav">
  <li><a href="adminpage.php">Home</a></li>
  <li><a href="search_card.php">Search Card</a></li>
  <li><a href="search_person.php">Search Staff</a></li>
  <li><a href="view_order_details.php">View All Orders</a></li>
<li><a href="view_order_history.php">View Staff History</a></li>
<li><a href="view_order_history_dept.php">View Line History</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>  	
</div>
<br />
<hr />
<h3 align="center">Admin Logged In</h2>
<hr />
<center>
<h2 align="center">Search By Card Number</h2>
<hr />
<form action="" method="post">
<table border="0" cellspacing="10" cellpadding="10">
  <tr>
    <td>Card Number</td>
    <td><span id="sprytextfield2">
      <label for="staff_id"></label>
      <input type="text" name="card_no" id="staff_id" />
      <span class="textfieldRequiredMsg">A value is required.</span></span></td>
  </tr>
  <tr>
    <td  align="center" colspan="2"><?php if(isset($msg)) echo $msg; ?></td>
    
  </tr><tr>
    <td  align="center" colspan="2"><input type="submit" name="sub" id="sub" value="Submit" />||<input name="" type="reset" value="Clear Form" /></td>   
  </tr>
  <tr>
   <td align="center" colspan="2"></td>
  </tr>
</table>
</form>



<?php
if (isset($_POST['sub'])){

	
     
	$card_no = $_POST['card_no'];
	
	
	$sql = $connection->query(
	"select s.staff_id as i, s.name as n, c.card_no as no, c.order_date as d,c.order_time as t, c.card_purpose as cp from card_orders c, staff s where c.card_no = '$card_no' and s.staff_id=c.staff_id
 ");
				$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
		$no=$sql->rowCount();   // number of rows affected by the last SQL statement  
if ($no == 0)
 {
 	echo "RECORD NOT FOUND";
 	}else{
	
echo '<p align="center"> Card Number  '.$card_no.'   details </p>
<table   align="center" cellpadding="5" cellspacing="5">
<tr>
    <th>Staff Number</th>
	<th>Staff Name</th>
	<th>Date</th>
    <th>Time</th>
    <th>Card Number</th>
    <th>Card Purpose</th>

</tr>';

	foreach($sql as $row)
	{
		$i = $row['i'];
	   $n = $row['n'];
	   $d = $row['d'];
	   $t = $row['t'];
	   $c = $row['no'];
	  $cp = $row['cp']; 

	   echo 
	"<tr>
	<td><a href=staff_order.php?id=$i>$i</a></td>
	<td>$n</td>	
	<td>$d</td>
    <td>$t</td>
    <td>$c</td>
    <td>$cp</td>";
	}
    echo "</tr>\n";
	echo '</table>';
	}
			 

	}
?>


<script type="text/javascript">
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {hint:"Enter number"});
</script>
</center>
</body>
</html>