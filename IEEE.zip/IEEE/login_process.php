<?php
session_start();
//connect to the d/b
$connection = mysql_connect("localhost", "root", "") or die("Could not connect to the MYSQL ".mysql_error()); 
$selection = mysql_select_db("IEEE") or die ("Could not connect to the database ".mysql_error());

if(isset($_POST['username']))
{
	$email = $_POST['username'];
	$password = $_POST['password'];
	
	$check = "SELECT * FROM students WHERE email='$username' and firstName='$password'";
	$check_res = mysql_query($check) or die ("invalid SQL query ".mysql_error());
	
	if($row = mysql_fetch_array($check_res))
	{
		if($email == $row['email'])
		{
			if($password == $row['firstName'])
			{
				//login succeed
				$_SESSION['email'] = $email;
				header("location:management.php");
				
			}
			else
			{
				//login failed
				?>
				<script>
					window.alert("Invalid e-mail or password. Please try again");
					
				</script>
				<?php
				header("location:login.html");
			}
		}
		else
		{
			//login failed
			?>
			<script>
			window.alert("Invalid e-mail or password. Please try again");
			
			</script>
			<?php
			header("location:login.html");
		}
	}
	else
	{
		//check for admin
		$check_uk = "SELECT * FROM Adminstration WHERE username='$username' and password='$password'";
		$check_uk_res = mysql_query($check_uk) or die ("invalid SQL query ".mysql_error());
			
		if($row = mysql_fetch_array($check_uk_res))
		{
			if($email == $row['username'])
			{
				if ($password == $row['password'])
				{
					$_SESSION['username'] = $email;
					
				}
				else
				{
					//login failed
					header("location:management.php");
				}
			}
			else
			{
				//login failed
				?>
				<script>
				window.alert("Invalid e-mail or password. Please try again");
				
				</script>
				<?php
				header("location:login.html");
		
				
			}
				
		}
		else
		{
			//login failed
			?>
			<script>
			window.alert("Invalid e-mail or password. Please try again");
			
			</script>
			<?php
			header("location:login.html");
		
		}
	}	
}
else
{
	//direct to login page
	header("location:login.html");
		
}


?>