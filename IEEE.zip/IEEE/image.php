<!DOCTYPE html>
<html>
<head>
    <title>Insert Image</title>
</head>
<body>

<form  method="post" enctype="multipart/form-data">
    <input type="file" name="image" /> 
    <input type="submit" name="submit" value="Submit"/>
</form>
 <?php
if( isset ($_POST['submit'])){
if(getimagesize($_FILES['image']['tmp_name'])==FALSE){
echo "please selct image";
}
else{
$image= addslashes($_FILES['image']['tmp_name']);
$name= addslashes($_FILES['image']['tmp_name']);
$image= file_get_contents($image);
$image= base64_encode($image);
saveimage($name, $image);
}
}
displayimage();
function saveimage ($name, $image){
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
 $db=mysql_select_db("TEST", $connection);
$query = "insert into store ( name, image) values ( '$name' ,  '$image' )";
$result = mysql_query($query,$connection);
if($result)
{
echo "<br/> Image upladed";
}
else{
echo "<br/> Image not upladed";
}


}
function displayimage(){
$connection = mysql_connect("localhost", "root", ""); 
$db = mysql_select_db("TEST", $connection);
$qry="select * from store";
$result = mysql_query($qry,$connection);
while($row = mysql_fetch_array($result)){
echo '<img height="300" width="300" src="data:image;base64,'
.$row[2].'">';
}
mysql_close($connection);

}


?>

</body>
</html>