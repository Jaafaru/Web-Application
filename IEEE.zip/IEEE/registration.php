<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<script src="../SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<script src="jquery-1.11.3.min.js"></script>
<script src="jquery.cycle.all.js"></script>
<style>
body {
background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
width: 100%;
height: 100%;
}


.maindiv {
margin: 30px auto;
width: 980px;
height: 500px;
background: #CCC;
padding-top: 20px;
font-family: 'Droid Serif', serif;
font-size: 14px
}
.title {
width: 500px;
height: 70px;
text-shadow: 2px 2px 2px #cfcfcf;
font-size: 16px;
text-align: center
}
.form_div {
width: 70%;
float: left
}
form {
width: 300px;
border: 1px dashed #aaa;
padding: 10px 30px 40px;
margin-left: 70px;
background-color: #FFF;
}
form h2 {
text-align: center;
text-shadow: 2px 2px 2px #cfcfcf
}
textarea {
width: 100%;
height: 60px;
border-radius: 1px;
box-shadow: 0 0 1px 2px #123456;
margin-top: 10px;
padding: 7px;
border: none
}
.input {
width: 100%;
height: 50px;
border-radius: 2px;
box-shadow: 0 0 1px 2px #123456;
margin-top: 10px;
padding: 7px;
border: none;
margin-bottom: 20px
}
.submit {
color: #fff;
border-radius: 3px;
background: #1F8DD6;
padding: 5px;
margin-top: 40px;
border: none;
width: 100%;
height: 30px;
box-shadow: 0 0 1px 2px #123456;
font-size: 18px
}
p {
color: red;
text-align: center
}
span {
text-align: center;
color: green
}
#event_registration {
	position: absolute;
	left: 296px;
	top: 254px;
}
#adminPanel {
position: absolute;
left: 208px;
top: 9px;
width: 809px;
font-family:Verdana, Geneva, sans-serif;
font-size:24px;
text-align:center;
}
#admin{
position: absolute;
font-size: 60px;
font-family: Arial, Helvetica, sans-serif;
color: #FFF;
left: 326px;
top: 32px;
width: 611px;
text-align: center;
}
#ad{
position: absolute;
left: 1050px;
top: 17px;
width: 169px;
height: 175px;
}
#use{
position: absolute;
left: 20px;
top: 105px;
height: 60px;
width: 583px;
color: #FFF;
font-size: 25px;
}
#mid{
position: absolute;
left: 443px;
top: 349px;
width: 1182px;
height: 1027px;
color: #FFF;
background-color: #CFF;
}
#panel-heading{
color:#009;
font-size:36px;
}
h1{
color:#CF0;
background-color:#000;
width:100%;
text-align:center;
font-family:Verdana, Geneva, sans-serif;
font-size:35px;
  
}
table{
position: absolute;
left: 2px;
top: 66px;
height: 141px;
}
.panel-body{
font-size:14px;
font-family:Arial, Helvetica, sans-serif;
}
  #wrap{
background-color: #FFF;
width: 1242px;
position: absolute;
left: 1px;
top: 129px;
height: 112px;
  }
  #ad{
position: absolute;
left: 1074px;
top: 17px;
width: 122px;
height: 100px;
}
 #use{
position: absolute;
left: 5px;
top: 69px;
height: 60px;
width: 100%;
color: #FFF;
font-size: 25px;
} 
#buttons{
position: absolute;
left: 703px;
top: 453px;
width: 280px;
height: 64px;
font-size: 50px;
}
 #display{
width: 100%;
height: 100px;
border-radius: 2px;
box-shadow: 0 0 1px 2px #123456;
margin-top: 10px;
padding: 7px;
border: none;
margin-bottom: 20px;
font-size:50px;
color:#9FC;
background:#333;
 }
 #logo{
	position: absolute;
	display: block;
	width: 253px;
	height: 111px;
	left: 11px;
	top: 5px;
	}
	#menu{
	position: absolute;
	width: 1220px;
	top: 131px;
	height: 79px;
	left: 101px;
	}
	#title{
	font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	font-size: 44px;
	color:white;
	position: absolute;
	top: 27px;
	left: 503px;
	width: 584px;
	height: 71px;
	}
	#uum{
	position: absolute;
	left: 1149px;
	top: 3px;
	width: 126px;
	height: 121px;
	}

  
</style>
</head>
<body >
<div id="menu">
<ul id="MenuBar1" class="MenuBarHorizontal">
<li><a href="index.html">HOME</a></li>
<li><a href="about.php">ABOUT</a></li>
<li><a href="event.php">EVENTS</a></li>
<li><a href="membership.html"> MEMBERSHIP</a></li>
<li><a href="contact.html"> CONTACT US </a></li>
</ul>
</div>
<label id="title"> UTARA STUDENT BRANCH</label>

<label id="uum"><img src="logo-uum.jpg" width="126" height="123"></label>

<div id="logo"><img src="eee.png" width="248" height="109"> </div>

<label id="uum"><img src="logo-uum.jpg" width="126" height="123"></label>



<div id="event_registration">
  <form action="signup.php" method="post" enctype="multipart/form-data">
    <!-- Method can be set as POST for hiding values in URL-->
    
    <h2>REGISTRATION FORM</h2>
    <label> First Name:</label>
<input class="input" name="firstname" placeholder="Salma" type="text" value="">
<label>Last Name:</label>
<input class="input" name="lastname" placeholder="Hussein" type="text" value="">


<label>Gender: </label>
<div id="input" class="input">
<input  name="sex"  type="radio" value="male">Male
<input  name="sex"  type="radio" value="female">Female <br></div>
<label>phone:</label>
<input class="input" name="phone" type="text" placeholder="(###-### ####)" value="">
<label>Email:</label>
<input class="input" name="email" type="text" placeholder="( salmahom02@gmail.com)"value="">
<label>Address:</label>
<input class="input" placeholder="uum, sintok" name="address" type="text" value="">
<label>Field Of Study</label>
<input class="input" placeholder="Student" name="field" type="text" value="">
<label>Position: </label>
<div id="input" class="input">
<input type="checkbox" name="position[]" value=" Executive Committe">
  EXECUTIVE MEMBER
  <input type="checkbox" name="position[]" value="member">
  MEMBER</label><br /></div>
<label>Biography</label>
<textarea class="input" cols="25" name="comment" rows="5"></textarea>
<label>Hobbies:</label>
<input class="input" placeholder="Diving" name="hobbies" type="text" value="">
    
    <label>Image:</label>
    <input class="input"type='file' name='image[]' accept='image/jpeg'>
    <input class="input"type="submit" name="submit" value="Submit" onclick=""/>
  </form>
</div>






</body>
</html>