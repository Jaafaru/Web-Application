<?php
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("IEEE", $connection); // Selecting Database from Server
// Fetching variables of the form which travels in URL

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$firstname = $_POST['firstname'];
$lastname=$_POST['lastname'];
$email = $_POST['email'];
$contact = $_POST['phone'];
$address = $_POST['address'];
$field=$_POST['field'];
$gender=$_POST['sex'];
$comment=$_POST['comment'];

$hobbies=$_POST['hobbies'];
$position =$_POST['position'];
$checkbox="";
foreach($position as $chk1)  
   {  
     $checkbox .= $chk1.",";  
   } 
   



if($firstname !=''|| $lastname !='' ||$email !='' || $checkbox  !=''   ) {
//Insert Query of SQL
$query = mysql_query("INSERT INTO students (firstName, lastName, phone, email,address,field,gender,Comments,Hobbies,Position) VALUES 
		('$firstname' , '$lastname' , '$contact' , '$email','$address','$field','$gender','$comment','$hobbies','$checkbox' )");
echo "<script>
alert('successfully inserted');
window.location.href='event.php';
</script>";
		}
	
}

else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}













?>












