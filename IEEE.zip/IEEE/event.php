<?php 

session_start();

mysql_connect("localhost", "root", "")or die("cannot connect to server");
mysql_select_db("IEEE")or die("cannot select db"); 

if(isset($_SESSION['username']))
{

	$username = $_SESSION['username']

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<script src="../SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<script src="jquery-1.11.3.min.js"></script>
<script src="jquery.cycle.all.js"></script>
<style>
body {
	background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
	width: 100%;
	height: 100%;
}


.maindiv {
	margin: 30px auto;
	width: 980px;
	height: 500px;
	background: #CCC;
	padding-top: 20px;
	font-family: 'Droid Serif', serif;
	font-size: 14px
}
.title {
	width: 500px;
	height: 70px;
	text-shadow: 2px 2px 2px #cfcfcf;
	font-size: 16px;
	text-align: center
}
.form_div {
	width: 70%;
	float: left
}
form {
	width: 300px;
	border: 1px dashed #aaa;
	padding: 10px 30px 40px;
	margin-left: 70px;
	background-color: #FFF;
}
form h2 {
	text-align: center;
	text-shadow: 2px 2px 2px #cfcfcf
}
textarea {
	width: 100%;
	height: 60px;
	border-radius: 1px;
	box-shadow: 0 0 1px 2px #123456;
	margin-top: 10px;
	padding: 7px;
	border: none
}
.input {
	width: 100%;
	height: 50px;
	border-radius: 2px;
	box-shadow: 0 0 1px 2px #123456;
	margin-top: 10px;
	padding: 7px;
	border: none;
	margin-bottom: 20px
}
.submit {
	color: #fff;
	border-radius: 3px;
	background: #1F8DD6;
	padding: 5px;
	margin-top: 40px;
	border: none;
	width: 100%;
	height: 30px;
	box-shadow: 0 0 1px 2px #123456;
	font-size: 18px
}
p {
	color: red;
	text-align: center
}
span {
	text-align: center;
	color: green
}
#event_registration {
	position: absolute;
	left: 244px;
	top: 308px;
}
#adminPanel {
	position: absolute;
	left: 208px;
	top: 9px;
	width: 809px;
	font-family:Verdana, Geneva, sans-serif;
	font-size:24px;
	text-align:center;
}
#admin{
position: absolute;
font-size: 60px;
font-family: Arial, Helvetica, sans-serif;
color: #FFF;
left: 326px;
top: 32px;
width: 611px;
text-align: center;
}
#ad{
position: absolute;
left: 1050px;
top: 17px;
width: 169px;
height: 175px;
}
#use{
	position: absolute;
	left: 20px;
	top: 105px;
	height: 60px;
	width: 583px;
	color: #FFF;
	font-size: 25px;
}
#mid{
	position: absolute;
	left: 443px;
	top: 349px;
	width: 1182px;
	height: 1027px;
	color: #FFF;
	background-color: #CFF;
}
#panel-heading{
	color:#009;
	font-size:36px;
}
h1{
	color:#CF0;
	background-color:#000;
	width:100%;
	text-align:center;
	font-family:Verdana, Geneva, sans-serif;
	font-size:35px;
  
}
table{
	position: absolute;
	left: 2px;
	top: 66px;
	height: 141px;
}
.panel-body{
	font-size:14px;
	font-family:Arial, Helvetica, sans-serif;
}
  #wrap{
	background-color: #FFF;
	width: 1242px;
	position: absolute;
	left: 1px;
	top: 129px;
	height: 112px;
  }
  #ad{
	position: absolute;
	left: 1074px;
	top: 17px;
	width: 122px;
	height: 100px;
}
 #use{
	position: absolute;
	left: 5px;
	top: 69px;
	height: 60px;
	width: 100%;
	color: #FFF;
	font-size: 25px;
} 
#buttons{
	position: absolute;
	left: 703px;
	top: 453px;
	width: 280px;
	height: 64px;
	font-size: 50px;
}
 #display{
	 width: 100%;
	height: 100px;
	border-radius: 2px;
	box-shadow: 0 0 1px 2px #123456;
	margin-top: 10px;
	padding: 7px;
	border: none;
	margin-bottom: 20px;
	font-size:50px;
	color:#9FC;
	background:#333;
 }

  
</style>
</head>
<body >


<div id="wrap">
<div id="adminPanel">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="management.php">Members</a></li>
    <li><a href="event.php">Events</a></li>
    <li><a href="FList.php">Feedback</a></li>
  </ul>
</div>
</div>
<span id="use"> 
<p>You have successfully logged in <?php echo "".$_SESSION['username']; ?></p></span>	
        	

<div id="event_registration">
  <form action="registerEvent.php" method="post" enctype="multipart/form-data">
    <!-- Method can be set as POST for hiding values in URL-->
    
    <h2>EVENT REGISTRATION</h2>
    <label> Date:</label>
    <input class="input"  type="date" name="date" maxlength="80">
    <label>Venue:</label>
    <input class="input" name="venue" type="text" value="">
    <label>Topic:</label>
    <input class="input" name="topic" type="text" value="">
    <label>Description:</label>
    <input class="input" name="description" type="text" value="">
    <label>Image:</label>
    <input class="input"type='file' name='image[]' accept='image/jpeg'>
    <input class="input"type="submit" name="submit" value="Submit" onclick=""/>
  </form>
</div>
<div id="buttons"><input class="input" type=button id="display" onClick="location.href='EList.php'" value='DISPLAY'></div>




<label id="ad"> <a href="logout.php" target="_blank"> <img src="logout.png"></a></label>
<h1>Welcome to the Admin Panel</h1>
</a>ss
</body>
</html><?php
	
}
else
{
	?>
    <script>alert('not connected ');</script>
    <?php
	
}
?>
