<?php
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("IEEE", $connection); // Selecting Database from Server
// Fetching variables of the form which travels in URL

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$firstname = $_POST['firstname'];
$lastname=$_POST['lastname'];
$email = $_POST['email'];
$contact = $_POST['phone'];
$address = $_POST['address'];
$field=$_POST['field'];
$gender=$_POST['sex'];
$comment=$_POST['comment'];

$hobbies=$_POST['hobbies'];
$position =$_POST['position'];
$checkbox="";
foreach($position as $chk1)  
   {  
     $checkbox .= $chk1.",";  
   } 
   

if(isset($_FILES['image']))
{
$name_array = $_FILES['image']['name'];
$tmp_name_array = $_FILES['image']['tmp_name'];
$type_array = $_FILES['image']['type'];
$size_array = $_FILES['image']['size'];
$error_array = $_FILES['image']['error'];
//echo "file ada : ".count($tmp_name_array)."<br>";
   for($i = 0; $i < count($tmp_name_array); $i++)
   {
if($error_array[$i] > 0)
{
echo 'Problem :';
switch ($error_array[$i])
{
case 1:
echo 'File exceed upload_max_filesize';
break;
case 2:
echo 'File exceed max_file_size';
break;
case 3:
echo 'File only partially uploaded';
break;
}
exit;
}//end of --> if($error_array[$i] > 0)
else
{
$temp = explode(".", $name_array[$i]);
$newfilename = round(microtime(true)) .'_'. uniqid() .'_'.$name_array[$i];
if(move_uploaded_file($tmp_name_array[$i], 'uploadedfiles/'. $newfilename))//-->"../uploadedfiles/" . $newfilename<-- location directory dan nama file, ikut akak punya directory untuk letak file-file tu. 
{
echo "upload successful : ".$newfilename;
}
else
{
echo "move file failed : ".$newfilename;
}

//Insert Query of SQL

if($firstname !=''|| $lastname !='' ||$email !='' || $checkbox  !=''   ) {
//Insert Query of SQL
$query = mysql_query("INSERT INTO students (firstName, lastName, phone, email,address,field,gender,Comments,Hobbies,Position,Image) VALUES 
		('$firstname' , '$lastname' , '$contact' , '$email','$address','$field','$gender','$comment','$hobbies','$checkbox','$newfilename' )");
echo "<script>
alert('successfully inserted');
window.location.href='login.html';
</script>";
		}
}//end of else
}//end of --> for($i = 0; $i < count($name_array); $i++)
}


	
}

	


else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}