<?php
ob_start();
session_start();
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("IEEE", $connection); // Selecting Database from Server
// Fetching variables of the form which travels in URL
// username and password sent from form 
$username=$_POST['username']; 
$password=$_POST['password'];
 // To protect MySQL injection (more detail about MySQL injection)
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);
$sql="SELECT * FROM Adminstration WHERE username='$username' and password='$password'";

$result=mysql_query($sql);

// Mysql_num_row is counting table row
$count=mysql_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row
if($count > 0){
$_SESSION['valid'] = true;
$_SESSION['timeout'] = time();
$_SESSION['username'] = $username;
header("location:management.php");
   

}
else {
echo "<script>
alert('Wrong Username or Password');
window.location.href='login.html';
</script>";
        

}
ob_end_flush();

mysql_close($connection); // Closing Connection with Server
?>