<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Up</title>
<script src="../SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<script src="jquery-1.11.3.min.js"></script>
<script src="jquery.cycle.all.js"></script>
<link href="style sheet.css">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
body {
	background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
	width: 100%;
	height: 100%;
}
#logo {
	position: absolute;
	display: block;
	width: 253px;
	height: 111px;
	left: 11px;
	top: 5px;
}
#menu {
	position: absolute;
	width: 1220px;
	top: 131px;
	height: 79px;
	left: 101px;
}
#title {
	font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	font-size: 44px;
	color: white;
	position: absolute;
	top: 27px;
	left: 503px;
	width: 584px;
	height: 71px;
}
#uum {
	position: absolute;
	left: 1149px;
	top: 3px;
	width: 126px;
	height: 121px;
}
#menu {
	position: absolute;
	width: 1220px;
	top: 131px;
	height: 79px;
	left: 101px;
}
#membe {
	position: absolute;
	background-image: url(mDmJcSD.jpg);
	font-size: 20px;
	text-align: center;
	font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	color: white;
	left: 5px;
	top: 366px;
	width: 1367px;
	height: 311px;
	opacity: 0.8;
}
#membe:hover {
	opacity: 1.0;
	filter: alpha(opacity=100); /* For IE8 and earlier */
}
#join {
	color: black;
	position: absolute;
	font: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	text-align: center;
	left: 7px;
	top: 266px;
	width: 1367px;
	height: 63px;
	font-size: 44px;
	background-color: #f2f2f2;
}
#joi {
	position: absolute;
	width: 754px;
	height: 252px;
	font-size: 20px;
	top: 14px;
	left: 20px;
}
#benefit {
	color: black;
	position: absolute;
	font: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
 font-size:
 text-align: center;
	left: 5px;
	top: 722px;
	width: 1367px;
	height: 63px;
	font-size: 44px;
	background-color: #f2f2f2;
}
.benefits {
	position: absolute;
	width: 1367px;
	height: 556px;
	left: 1px;
	top: 805px;
	text-align: center;
	background-image: url(simple-light-tumblr-background-5eau4rsx6.jpg);
	font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	font-size: 20px;
}
#description {
	position: absolute;
	font-size: 20px;
	font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	left: 1px;
	top: 5px;
	height: 72px;
	width: 1038px;
	border-color: black;
}
#knowledge {
	position: absolute;
	left: 16px;
	top: 114px;
	width: 363px;
	height: 397px;
	opacity: 0.9;
}
#lass {
	position: absolute;
	left: 27px;
	top: 295px;
	width: 344px;
	height: 213px;
	text-align: left;
	opacity: 0.9;
}
#community {
	position: absolute;
	left: 405px;
	top: 114px;
	width: 571px;
	height: 406px;
	opacity: 0.9;
	text-align: left;
}
#comm {
	position: absolute;
	left: 427px;
	top: 295px;
	width: 344px;
	height: 213px;
	text-align: left;
	opacity: 0.9;
}
#profession {
	position: absolute;
	left: 997px;
	top: 114px;
	width: 358px;
	height: 406px;
	opacity: 0.9;
	text-align: left;
}
#profess {
	position: absolute;
	left: 1002px;
	top: 295px;
	width: 344px;
	height: 213px;
	text-align: left;
	opacity: 0.9;
}
#register {
	position: absolute;
	left: 970px;
	width: 284px;
	top: 9px;
	height: 273px;
}

#popupBoxOnePosition{
				top: 0; right:10%; position: fixed; width: 900px; height:900px;
				background-color: rgba(0,0,0,0.7); display: none;
				
			}
			
			.popupBoxWrapper{
				width: 900px; height:900px; margin: 50px auto; text-align: left;
			}
			.popupBoxContent{
				background-color: #FFF; padding: 15px; width: 900px; height:900px
			}
			#close{
				right:10;
				top:10;
				float:right;
			}
			
</style>
<script type="text/javascript">
			<!--
			    function toggle_visibility(id) {
			       var e = document.getElementById(id);
			       if(e.style.display == 'block')
			          e.style.display = 'none';
			       else
			          e.style.display = 'block';
			    }
			//-->
		</script>
</head>

<body style="padding-top: 70px"  >
<div id="logo"><img src="eee.png" width="248" height="109"> </div>
<label id="title"> UTARA STUDENT BRANCH</label>
<label id="uum"><img src="logo-uum.jpg" width="126" height="123"></label>
<div id="menu">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="index.html">HOME</a></li>
    <li><a href="#">ABOUT</a></li>
    <li><a href="#">EVENTS</a></li>
    <li><a href="membership.html"> MEMBERSHIP</a></li>
    <li><a href="#"> CONTACT US </a></li>
  </ul>
</div>
<label id="join"> WHY JOIN IEEE UUM ?</label>
<div id="membe">
  <p id="joi"> When you join IEEE, you join a community of over 425,000 technology and engineering professionals united by a common desire to continuously learn, interact, collaborate, and innovate.<br>
    <br>
    IEEE Membership provides you with the resources and opportunities you need to keep on top of changes in technology; get involved in standards development; network with other professionals in your local area or within a specific technical interest; mentor the next generation of engineers and technologists, and so much more. </p>
  <div id="register">

			<a  href="javascript:void(0)"  onclick="toggle_visibility('popupBoxOnePosition');" ><img src="join-button-hi.png" width="271" height="290"></a></p>
			

		</div>
</div>

<div id="popupBoxOnePosition" style="display: none;">
			<div class="popupBoxWrapper">
				<div class="popupBoxContent">
					<h3>Registration form </h3>
					<form action="signup.php" method="post">
  <table id="table" width="603" height="487" border="2">
  <tbody>
    <tr>
      <td width="199">FIRST NAME: </td>
      <td width="305"> <input type="firstName" size="50" maxlength="80" id="firstName" placeholder="Salma" name="firstName"></td>
    </tr>
    <tr>
      <td>LAST NAME :</td>
      <td> <input type="lastName" size="50" maxlength="80" id="lastName" placeholder="Hussein" name="lastName"></td>
    </tr>
    <tr>
      <td>ADDRESS :</td>
      <td><input type="address" size="50" maxlength="80" id="address" placeholder="" name="address"></td>
    </tr>
    <tr>
      <td>PHONE :</td>
      <td><input type="tel" size="50" maxlength="80" id="tel" placeholder="(###-### ####)" name="telephone"></td>
    </tr>
    <tr>
      <td>EMAIL :</td>
      <td><input type="email" size="50" maxlength="80" id="email" name="email" placeholder="( salmahom02@gmail.com)"> </td>
    </tr>
    <tr>
      <td>FIELD STUDIED</td>
      <td><input type="fieldstudy" size="50" maxlength="80" id="fieldStudy" name="field" placeholder="Student"></td>
    </tr>
    <tr>
      <td>DATE JOINED</td>
      <td> <input type="date" name="dateJoined" maxlength="80" id="date" name="date"></td>
    </tr>
    <tr>
      <td height="119">BIOGRAPHY</td>
      <td> <TEXTAREA NAME="comments" COLS=50 ROWS=7></TEXTAREA> </td>
    </tr>
    <tr>
      <td>HOBBIES</td>
      <td><input type="hobbies" size="50" maxlength="80" id="hobbies" placeholder="Diving" name="hobbies"></td>
    </tr>
    <tr>
      <td>IMAGE</td>
      <td><input type="file" name="fileToUpload" id="fileToUpload" maxlength="80" name="image"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" value="Submit"></td>
    </tr>
  </tbody>
</table>

  
  
  
  
</form>
					<button id="close"  onclick="toggle_visibility('popupBoxOnePosition');">X</button>				</div>
			</div>
		</div>



<label id="benefit"> THE BENEFITS OF MEMBERSHIP</label>
<div class="benefits">
  <p id="description">Core Benefits - IEEE is the world's largest technical society, bringing Members access to the industry's most
    essential technical Information, networking opportunities, career development tools, and many other exclusive benefits. </p>
  <p id="knowledge">Knowledge - Staying current with the fast-changing world of technology…<BR>
  <div id="lass"> <a href="http://spectrum.ieee.org/" > IEEE Spectrum</a><br>
    <br>
    <a href="http://www.ieee.org/publications_standards/index.html" > IEEE Potentials Magazines</a><br>
    <br>
    <a href="http://ieeexplore.ieee.org/Xplore/home.jsp" > IEEE Xplore</a><br>
    <br>
  </div>
  </p>
  <p id="community"> Community - As the world's largest technical association, IEEE is comprised of a variety of groups, active in publications, conferences, and building technical communities.<br>
    IEEE membership offers several benefits that will help you keep connected and buy power of a global community of professionals with over 400,000 members in 160 countries. <br>
  <div id="comm"> <a href="http://www.ieee.org/membership_services/membership/students/index.html" > Volunteering</a><br>
    <br>
    <a href="http://www.ieee.org/web/membership/benefits/products/prod_emailalias.html" > IEEE e-mail alias</a><br>
    <br>
    <a href="http://www.ieee.org/web/membership/benefits/products/prod_chapters.html" > Technical Chapters</a><br>
    <br>
  </div>
  </p>
  <p id="profession">Profession- IEEE membership builds a platform to introduce technology careers to students, to empower them to build and own their careers, and to enhance their resume. <br>
  <div id="profess"> <a href="http://careers.ieee.org/" > IEEE Job Site</a><br>
    <br>
    <a href="http://www.ieee.org/membership_services/membership/students/competitions/index.html" > Student Competitions</a><br>
    <br>
    <a href="http://www.ieee.org/membership_services/membership/students/awards/index.html" > Awards, Scholaeships, and Fellowships</a><br>
    <br>
  </div>
  </p>
</div>
<script src="js/bootstrap.js" type="text/javascript"></script>
</body>
</html>
