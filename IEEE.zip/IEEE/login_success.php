<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Admin Page</title>
<style>
body {
	background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
}
#adminPanel {
	position: absolute;
	left: 261px;
	top: 203px;
	width: 727px;
}
#admin{
	position: absolute;
	font-size: 60px;
	font-family: Arial, Helvetica, sans-serif;
	color: #FFF;
	left: 326px;
	top: 32px;
	width: 611px;
	text-align: center;
}
#ad{
	position: absolute;
	left: 1050px;
	top: 17px;
	width: 169px;
	height: 175px;
}	
	
</style>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
</head>
<body>
<div id="adminPanel">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="#">Members</a></li>
    <li><a href="#">Events</a></li>
    <li><a href="#">Feedback</a></li>
  </ul>
</div>

<label id="admin"> ADMIN PANEL</label>
<label id="ad"> <a href="logout.php" target="_blank"> 
<img src="red-logout.png" width="169" height="180"></a></label>


<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>