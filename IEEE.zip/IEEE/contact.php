<?php
if(isset($_POST['submit'])) 
{ 
    $name = $_POST['name'];
	$email =$_POST["email"];
$subject=$_POST["subject"];
$message =$_POST["message"];
$to="salmahom02@gmail.com";

mail( $to, $subject, $message, "From:". $name);
$success = "sent";
alert ("User Has submitted the form and entered this name : <b> $name </b>");
    
}
?>





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
<script src="../SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<script src="jquery-1.11.3.min.js"></script>
<script src="jquery.cycle.all.js"></script>
<style>
body{
	background-image:url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
	width:100%;
	height:100%;
}

	#logo{
	position: absolute;
	display: block;
	width: 253px;
	height: 111px;
	left: 11px;
	top: 4px;
	}
	#menu{
	position: absolute;
	width: 1220px;
	top: 131px;
	height: 79px;
	left: 101px;
	}
	#title{
	font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
	font-size: 44px;
	color:white;
	position: absolute;
	top: 27px;
	left: 503px;
	width: 584px;
	height: 71px;
	}
	#uum{
	position: absolute;
	left: 1149px;
	top: 3px;
	width: 126px;
	height: 121px;
	}
#feedback{
	position: absolute;
	left: 650px;
	top: 760px;
	width: 562px;
	height: 255px;
}
#map{
	position: absolute;
	background-color: #CCC;
	left: 0px;
	top: 246px;
	width: 1332px;
	height: 330px;
}
#us{
	position: absolute;
	font-size: 48px;
	font-family: Arial, Helvetica, sans-serif;
	color: #FFF;
	left: -8px;
	top: 630px;
	width: 1336px;
	background-color: #333;
	text-align: center;
}
#facebook{
	position: absolute;
	left: 568px;
	top: 901px;
	width: 148px;
	height: 127px;
	background-color:#FFF;
}
#contactForm{
	position: absolute;
	left: 44px;
	top: 763px;
	width: 448px;
	height: 608px;
	background-color:#9CF;
	text-align: center;
}
form.email p {
font-size: 15px;
padding: 0 0 10px 0;
margin: 0;
}

form.email input, form.email textarea {
font-family: Arial;
font-size: 15px;
margin: 0 0 20px 0;

}

form.email input {
background: #f5f5f5;
padding: 5px;
border: 1px solid #bbb;
border-radius: 5px;
text-align:center;
}

form.email textarea {
background: #f5f5f5;
padding: 5px;
border: 1px solid #bbb;
border-radius: 5px;
width: 400px;
height: 250px;
}

form.email input.send {
color:#000;
background:#FFF;
border: #000;
padding: 10px 25px 10px 25px;
cursor: pointer;
}


</style>
<script type="text/javascript"
    src="http://maps.google.com/maps/api/js?sensor=false">
</script>
<script type="text/javascript">
  function initialize() {
    var position = new google.maps.LatLng(6.4575096, 100.5032646);
    var myOptions = {
      zoom: 10,
      center: position,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(
        document.getElementById("map"),
        myOptions);
 
    var marker = new google.maps.Marker({
        position: position,
        map: map,
        title:"This is the place."
    });  
 
    var contentString = 'We are <strong>Here</strong>!';
    var infowindow = new google.maps.InfoWindow({
        content: contentString
    });
 
    google.maps.event.addListener(marker, 'click', function() {
      infowindow.open(map,marker);
    });
 
  }
 
</script>
    <script type='text/javascript'>
// <![CDATA[

    var frmvalidator  = new Validator("contactus");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();
    frmvalidator.addValidation("name","req","Please provide your name");

    frmvalidator.addValidation("email","req","Please provide your email address");

    frmvalidator.addValidation("email","email","Please provide a valid email address");

    frmvalidator.addValidation("message","maxlen=2048","The message is too long!(more than 2KB!)");

// ]]>
</script>




</head>
<body onload="initialize()">
<div id="logo"><img src="eee.png" width="248" height="109"> </div>
<div id="menu">
<ul id="MenuBar1" class="MenuBarHorizontal">
<li><a href="index.html">HOME</a></li>
<li><a href="#">ABOUT</a></li>
<li><a href="#">EVENTS</a></li>
<li><a href="membership.html"> MEMBERSHIP</a></li>
<li><a href="#"> CONTACT US </a></li>
</ul>
</div>
<label id="title"> UTARA STUDENT BRANCH</label>

<label id="uum"><img src="logo-uum.jpg" width="126" height="123"></label>

<div id="map"> </div>

<span id="us"> Contact Us </span>
<span id="facebook"> <img src="facebook.png" width="150" height="150" /></span>
<div id="contactForm">
<form class="email" action="mailer.php" method="post">
  <p>Name:</p>
<input type="text" name="name" />
<p>E-mail:</p>
<input type="text" name="email" />
<p>Subject:</p>
<input type="text" name="subject" />
<p>Message:</p>
<textarea name="message"></textarea></p><br/>
<input class="send" type="submit" value="Send" />

</form>
</div>







</body>
</html>