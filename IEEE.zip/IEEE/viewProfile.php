<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Member| View Profile</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/home.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <?php
  	session_start();
	
	if(isset($_SESSION['email']))
	{
		$email = $_SESSION['email'];
		
		$connection = mysql_connect("localhost", "root", "") or die("Could not connect to the MYSQL ".mysql_error()); 
		$selection = mysql_select_db("usafety") or die ("Could not connect to the database ".mysql_error());
		
		//getting the name of the user logged in
		$getname = "SELECT name FROM user WHERE (email = '$email')";
		$name_res = mysql_query($getname) or die ("invalid SQL query ".mysql_error());
		while($row = mysql_fetch_array($name_res))
		{
			$name = $row['name'];
		}
	  ?>
  <body>
    <!-- navbar as header -->
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="../homemenu.php">U-SAFETY</a>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo"Hello, $name" ?>
							<span class="caret"></span></a>
							<ul class="dropdown-menu">
								<li><a href="../processes/logout_process.php">Logout</a></li>
							</ul>
						</li>
					</ul>
				</div> 
			</div>
		</div>
	<!-- end of navbar as header -->
	
    <div class="container-fluid">
    	<div class="row">
        	<!--sidebar-->
            <div class="col-md-2">
				<ul class="nav nav-pills nav-stacked nav-sidebar">
					<li><a href="../homemenu.php">Complaint History</a></li>
					<li><a href="makecomplaint.php">Make a Complaint</a></li>
            		<li class="active"><a href="viewprofile.php">View Profile</a></li>
				</ul>
			</div><!--end of sidebar-->
            
            <div class="col-md-10">
                <form class="form-horizontal">
                    <div class="container">
                        <h1>Profile</h1>
                        <br><br>
                        <?php
                            //get user data
                            $showuser = "SELECT * FROM user WHERE email = '$email'";
                            $showuser_res = mysql_query($showuser) or die ("SQL Statement failed" .mysql_error());
                                
                            while ($row = mysql_fetch_array($showuser_res))
                            {
                                $name = $row['name'];
                                $email = $row['email'];
                                $icpass = $row['icpass'];
                                $phone = $row['phone'];
                                $usertype = $row['usertype'];
								$pp = $row['pp'];
                                    
                            }
							
							if($pp == null)
							{
								$pp = "default.jpg";
							}
                                
                            //display user data
                            echo"
                                
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>Profile Picture :</label>
                                <div class='col-sm-5'>
                                    <div class='col-sm-4 thumb'>
										<a class='thumbnail' data-image-id='' data-toggle='modal' data-image='http://localhost/U-SAFETY/uploadedfiles/$pp' data-target='#image-gallery'>
											<img src='../pp/$pp'>
										</a>
									</div>
                                </div>
                            </div>
							<div class='form-group'>
                                <label class='control-label col-sm-2'>Name :</label>
                                <div class='col-sm-5'>
                                    $name
                                </div>
                            </div>
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>E-Mail :</label>
                                <div class='col-sm-5'>
                                    <p>$email</p>
                                </div>
                            </div>
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>IC / Passport Number :</label>
                                <div class='col-sm-5'>
                                    <p>$icpass</p>
                                </div>
                            </div>
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>Phone :</label>
                                <div class='col-sm-5'>
                                    <p>$phone</p>
                                </div>
                            </div>
                            ";
                                
                            //if usertype == student, display student data
                            if($usertype == 'student')
                            {
                                    $showstudent = "SELECT * FROM student WHERE email = '$email'";
                                    $showstudent_res = mysql_query($showstudent) or die ("SQL Statement failed" .mysql_error());
                                    
                                    while($row = mysql_fetch_array($showstudent_res))
                                    {
                                        $student_no = $row['student_no'];
                                        $student_dpp = $row['student_dpp'];
                                        $student_roomno = $row['student_roomno'];
                                    }
                                    echo"
                                    
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>Matric Number :</label>
                                        <div class='col-sm-5'>
                                            <p>$student_no</p>
                                        </div>
                                    </div>
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>DPP :</label>
                                        <div class='col-sm-5'>
                                            <p>$student_dpp</p>
                                        </div>
                                    </div>
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>Room Number :</label>
                                        <div class='col-sm-5'>
                                            <p>$student_roomno</p>
                                        </div>
                                    </div>
                                    ";
                                }
                            //else if usertype == staff, display staff data 
                            else if($usertype == 'staff')
                                {
                                    
                                    $showstaff = "SELECT * FROM staff WHERE email = '$email'";
                                    $showstaff_res = mysql_query($showstaff) or die ("SQL Statement failed" .mysql_error());
                                    
                                    while($row = mysql_fetch_array($showstaff_res))
                                    {
                                        $staff_no = $row['staff_no'];
                                        $staff_uumadd = $row['staff_uumadd'];
                                        $staff_school = $row['staff_school'];
                                        $staff_roomno = $row['staff_roomno'];
                                        $staff_extno = $row['staff_extno'];
                                        
                                    }
                                    echo"
                                    
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>Staff Number :</label>
                                        <div class='col-sm-5'>
                                            <p>$staff_no</p>
                                        </div>
                                    </div>
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>UUM Address :</label>
                                        <div class='col-sm-5'>
                                            <p>$staff_uumadd</p>
                                        </div>
                                    </div>
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>School :</label>
                                        <div class='col-sm-5'>
                                            <p>$staff_school</p>
                                        </div>
                                    </div>
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>Room Number :</label>
                                        <div class='col-sm-5'>
                                            <p>$staff_roomno</p>
                                        </div>
                                    </div>
                                    <div class='form-group'>
                                        <label class='control-label col-sm-2'>Extension Number :</label>
                                        <div class='col-sm-5'>
                                            <p>$staff_extno</p>
                                        </div>
                                    </div>
                                    ";
                                }
                                
                        ?>
                        <br><br>
                        <button type="button" class="btn btn-default" onClick="editprofile()">Edit Profile</button>
                        <!--function to direct to edit profile-->
						<script>
                            function editprofile()
                            {
                                window.location.assign("http://localhost/U-SAFETY/studentandstaff/editprofile.php");
                            }
                        </script>
                    </div><!--end of container-->
                </form>
            </div><!--end of col-md-10-->
        </div><!--end of row-->
    </div><!--end of container-->         
        

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
  <?php
	}
	else
	{
		?>
        	<script>
				window.location.assign("http://localhost/U-SAFETY/login.php");
			</script>
        <?php
	}
  ?>	
</html>