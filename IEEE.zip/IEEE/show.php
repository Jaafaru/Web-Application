 <?php
if( isset ($_POST['submit'])){
	if(getimagesize($_FILES['image']['tmp_name'])==FALSE){
		echo "please selct image";
		}
	else{
		$image= addslashes($_FILES['image']['tmp_name']);
		$name= addslashes($_FILES['image']['tmp_name']);
		$image= file_get_contents($image);
		$image= base64_encode($image);
		saveimage($name, $image);
	}	
}
function saveimage ($name, $image){
	$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("TEST", $connection);
	$query = mysql_query("INSERT INTO store ( name, image) VALUES ( '$name' ,  '$image' )");
	 $result = mysqli_prepare($con,$query);
if($result)
{
		echo "<br/> Image upladed";
		}
		else{
			echo "<br/> Image not upladed";
		}


}



?>