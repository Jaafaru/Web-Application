<?php 

//include('file:///Macintosh HD/Users/salma/Downloads/header.php');

mysql_connect("localhost", "root", "")or die("cannot connect to server");
mysql_select_db("IEEE")or die("cannot select db"); 

if(isset($_GET['del'])){

	$delete_Name = $_GET['del'];
	
	$delete_query = "delete from EVENTS where eventID='$delete_Name' ";
	
	if(mysql_query($delete_query)){
	header("location: EList.php");
	 
	}
}
?>
