<?php
session_start();
if(isset($_SESSION['username']))
{
	$new_fname = $_POST['firstname'];
	$new_lname = $_POST['lastname'];
	$new_phone = $_POST['phone'];
	$new_email = $_POST['email'];
	$new_address = $_POST['address'];
	$new_field = $_POST['field'];
	$new_comments = $_POST['comments'];
	$new_hobbies = $_POST['hobbies'];
	$email = $_SESSION['username'];
	//connect to the d/b
	$connection = mysql_connect("localhost", "root", "") or die("Could not connect to the MYSQL ".mysql_error()); 
	$selection = mysql_select_db("IEEE") or die ("Could not connect to the database ".mysql_error());
	
	//edit profile picture
	if(isset($_FILES['image']))
	{
		$name_array = $_FILES['image']['name'];
		$tmp_name_array = $_FILES['image']['tmp_name'];
		$type_array = $_FILES['image']['type'];
		$size_array = $_FILES['image']['size'];
		$error_array = $_FILES['image']['error'];
		
		if($error_array <= 0)
		{
			$temp = explode(".", $name_array);
			$newfilename = round(microtime(true)) .'_'. uniqid() .'_'.$name_array;
			
			if(move_uploaded_file($tmp_name_array, "../uploadedfiles/" . $newfilename))
			{
				echo "upload successful : ".$newfilename;
				
	$updateuserprofile ="UPDATE students SET firstName='$new_fname',lastName='$new_lname',phone='$new_phone',email='$new_email',
	address='$new_address',
	field='$new_field ',Comments='$new_comments',
	Hobbies='$new_hobbies', Image='$newfilename' WHERE  email='$email'";
	$updateuserprofile_res = mysql_query($updateuserprofile) or die ("SQL Statement failed ".mysql_error());
	
	$_SESSION['email'] = $new_email;
				
			}
			else
			{
				echo "move file failed : ".$newfilename;
				
                               }
		}
		else if($error_array == 1)
		{
			echo 'File exceed upload_max_filesize';
		}
		else if($error_array == 2)
		{
			echo 'File exceed max_file_size';
		}
		else if($error_array == 3)
		{
			echo 'File only partially uploaded';
		}
		
	}
	
	
	
	
	
	
	
	//edit student profile
	
	

	//redirect to "View Profile" page
	?>
	<script>
		window.alert("Updating Profile Successful");
		window.location.assign("http://localhost/IEEE/mana.php");
	</script>
	<?php
	
}
else
{
	//redirect to "Login" page
	?>
	<script>
		window.location.assign("http://localhost/IEEE/login.html");
	</script>
	<?php
}
?>