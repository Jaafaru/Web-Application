<?php 

session_start();

mysql_connect("localhost", "root", "")or die("cannot connect to server");
mysql_select_db("IEEE")or die("cannot select db"); 


?>
<html>
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="css2/bootstrap.css" />
    <link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <style>
  body {
background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
}



#use{
	position: absolute;
	left: 20px;
	top: 105px;
	height: 60px;
	width: 583px;
	color: #FFF;
	font-size: 25px;
}
#mid{
	position: absolute;
	left: 22px;
	top: 312px;
	width: 1164px;
	height: 1606px;
	color: #FFF;
	background-color: #CFF;
}
#panel-heading{
	color:#009;
	font-size:36px;
}
h1{
	color:#CF0;
	background-color:#000;
	width:100%;
	text-align:center;
	font-family:Verdana, Geneva, sans-serif;
	font-size:35px;
  
}
table{
	position: absolute;
	left: 2px;
	top: 66px;
	height: 141px;
}
.panel-body{
	font-size:14px;
	font-family:Arial, Helvetica, sans-serif;
}
  #wrap{
	background-color: #FFF;
	width: 100%;
	position: absolute;
	left: 1px;
	top: 129px;
	height:100%;
  }
  
 #use{
	position: absolute;
	left: 5px;
	top: 69px;
	height: 60px;
	width: 100%;
	color: #FFF;
	font-size: 25px;
} 
#logo{
position: absolute;
display: block;
width: 253px;
height: 111px;
left: 11px;
top: 5px;
}
#menu{
position: absolute;
width: 1220px;
top: 131px;
height: 79px;
left: 101px;
}
#title{
font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
font-size: 44px;
color:white;
position: absolute;
top: 27px;
left: 503px;
width: 584px;
height: 71px;
}
#uum{
position: absolute;
left: 1149px;
top: 3px;
width: 126px;
height: 121px;
}
#ad{
position: absolute;
left: 1050px;
top: 17px;
width: 169px;
height: 175px;
}
#menu{
	position: absolute;
	width: 1220px;
	top: 131px;
	height: 79px;
	left: 101px;
	}
	#sear{
	position: absolute;
	left: 1000px;
	top: 259px;
	}
  
  
  </style>
</head>  
	
<body>
<div id="logo"><img src="eee.png" width="248" height="109"> </div>


<div id="menu">
<ul id="MenuBar1" class="MenuBarHorizontal">
<li><a href="index.html">HOME</a></li>
<li><a href="about.html">ABOUT</a></li>
<li><a href="eve.php">EVENTS</a></li>
<li><a href="membership.html"> MEMBERSHIP</a></li>
<li><a href="contact.html"> CONTACT US </a></li>
</ul>
</div>
<div id="sear">
<form action="search.php" method="GET">
    <input type="text" name="query" />
    <input type="submit" value="Search" />
</form></div>

<label id="title"> UTARA STUDENT BRANCH</label>

<label id="uum"><img src="logo-uum.jpg" width="126" height="123"></label>
<div id="login"><a href="login.html" target="_blank"> 
<img src="login.png" width="119" height="33"></a>   </div>
</div>
<div class="panel panel-info" id="mid">
  <div id="panel-heading"> LIST OF EVENTS</div>
				  <div class="panel-body">
				  <?php	
				  $getdata = "SELECT * FROM EVENTS"; 
					$data_res = mysql_query($getdata) or die ("invalid SQL query ".mysql_error());?>
					
				  <table width="150%" height="1000"  class="table table-bordered">
					<thead>
								<tr class ="active">
								
								<td ><center>DATE</center></td>
								<td ><center>VENUE</center></td>
								<td ><center>TOPIC</center></td>
								<td ><center>DESCRIPTION </center></td>
								<td ><center>IMAGE</center></td>
								
                              
								</tr>
					</thead>
				  
					<?php
					
					
					
					
					
					
				

					while($row = mysql_fetch_array($data_res))
					{
						
						 $date =$row['Date'] ;
						 $venue = $row['Venue'];
						 $topic = $row['Topic'];
						 $description = $row['Description'] ;
						 $image= $row['Image'];?>
					<center>
					<tr>
                    
					
					
					
					<td><?php echo "". $date?></td>
                    <td><?php echo "". $venue ?></td>
                    <td><?php echo "". $topic ?></td>
                    <td><?php echo "".$description ?></td>
					
						
              <td><a class='thumbnail' href='#' data-image-id='' data-toggle='modal' data-image='uploadedfiles/<?php echo "$image" ?>' data-target='#image-gallery'>
							<img height="100" width="100" src="uploadedfiles/<?php echo "$image" ?>">
						</a></td>
                      
}
					
                    <td><center>
					</center></td>
                    
					</tr>
					</center>
					<?php 
					} 
					?>
				  </table>
 </div>
</div>

</body>
</html>
