<?php
session_start();
//connect to the d/b
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("IEEE", $connection);
$username=$_POST['username']; 
$password=$_POST['password'];
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

$isAdmin = mysql_query("SELECT username FROM Adminstration WHERE username = '$username' AND password = '$password'");
        if(mysql_num_rows($isAdmin) == 1) {
               $_SESSION['valid'] = true;
$_SESSION['timeout'] = time();
$_SESSION['username'] = $username;
header("location:management.php");
                exit;}
$result = mysql_query("SELECT email FROM students WHERE email = '$username' AND firstName = '$password'");
if(mysql_num_rows($result) == 1) {
                $_SESSION['valid'] = true;
$_SESSION['timeout'] = time();
$_SESSION['username'] = $username;
header("location:mana.php");
                exit; } 

else {
echo "<script>
alert('Wrong Username or Password');
window.location.href='login.html';
</script>";
}







ob_end_flush();

mysql_close($connection); // Closing Connection with Server

?>