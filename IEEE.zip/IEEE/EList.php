<?php 

session_start();

mysql_connect("localhost", "root", "")or die("cannot connect to server");
mysql_select_db("IEEE")or die("cannot select db"); 

if(isset($_SESSION['username']))
{

	$username = $_SESSION['username']

?>
<html>
<head>
  <title>Admin Panel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="css2/bootstrap.css" />
    <link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <style>
  body {
background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
}
#adminPanel {
	position: absolute;
	left: 208px;
	top: 9px;
	width: 809px;
	font-family:Verdana, Geneva, sans-serif;
	font-size:24px;
	text-align:center;
}
#admin{
position: absolute;
font-size: 60px;
font-family: Arial, Helvetica, sans-serif;
color: #FFF;
left: 326px;
top: 32px;
width: 611px;
text-align: center;
}
#ad{
position: absolute;
left: 1050px;
top: 17px;
width: 169px;
height: 175px;
}
#use{
	position: absolute;
	left: 20px;
	top: 105px;
	height: 60px;
	width: 583px;
	color: #FFF;
	font-size: 25px;
}
#mid{
	position: absolute;
	left: 22px;
	top: 312px;
	width: 1164px;
	height: 1606px;
	color: #FFF;
	background-color: #CFF;
}
#panel-heading{
	color:#009;
	font-size:36px;
}
h1{
	color:#CF0;
	background-color:#000;
	width:100%;
	text-align:center;
	font-family:Verdana, Geneva, sans-serif;
	font-size:35px;
  
}
table{
	position: absolute;
	left: 2px;
	top: 66px;
	height: 141px;
}
.panel-body{
	font-size:14px;
	font-family:Arial, Helvetica, sans-serif;
}
  #wrap{
	background-color: #FFF;
	width: 100%;
	position: absolute;
	left: 1px;
	top: 129px;
	height:100%;
  }
  #ad{
	position: absolute;
	left: 1074px;
	top: 17px;
	width: 122px;
	height: 100px;
}
 #use{
	position: absolute;
	left: 5px;
	top: 69px;
	height: 60px;
	width: 100%;
	color: #FFF;
	font-size: 25px;
} 
  
  
  </style>
</head>  
	
<body>
<div id="wrap">
<div id="adminPanel">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="management.php">Members</a></li>
    <li><a href="event.php">Events</a></li>
    <li><a href="FList.php">Feedback</a></li>
  </ul>
</div>
</div>
	
<span id="use"> 
<p>You have successfully logged in <?php echo "".$_SESSION['username']; ?></p></span>	
        	
	
  	
<label id="ad"> <a href="logout.php" target="_blank"> 
<img src="logout.png"></a></label>


<h1>Welcome to the Admin Panel</h1></a>
<div class="panel panel-info" id="mid">
				<div id="panel-heading"> LIST OF EVENTS</div>
				  <div class="panel-body">
				  <?php	
				  $getdata = "SELECT * FROM EVENTS"; 
					$data_res = mysql_query($getdata) or die ("invalid SQL query ".mysql_error());?>
					
				  <table width="150%" height="1000"  class="table table-bordered">
					<thead>
								<tr class ="active">
								<td width="10%"><center>EVENT</center></td>
								<td ><center>DATE</center></td>
								<td ><center>VENUE</center></td>
								<td ><center>TOPIC</center></td>
								<td ><center>DESCRIPTION </center></td>
								<td ><center>IMAGE</center></td>
								
                               <td><center>Operation</center></td>
								</tr>
					</thead>
				  
					<?php
					
					
					
					
					
					
				

					while($row = mysql_fetch_array($data_res))
					{
						 $eventid = $row['eventID'];
						 $date =$row['Date'] ;
						 $venue = $row['Venue'];
						 $topic = $row['Topic'];
						 $description = $row['Description'] ;
						 $image= $row['Image'];?>
					<center>
					<tr>
                    
					
					
					<td><?php echo "".$eventid ?></a></td>
					<td><?php echo "". $date?></td>
                    <td><?php echo "". $venue ?></td>
                    <td><?php echo "". $topic ?></td>
                    <td><?php echo "".$description ?></td>
					
						
              <td><a class='thumbnail' href='#' data-image-id='' data-toggle='modal' data-image='uploadedfiles/<?php echo "$image" ?>' data-target='#image-gallery'>
							<img height="100" width="100" src="uploadedfiles/<?php echo "$image" ?>">
						</a></td>
                      
}
					 <td><center><a  href="deleteEvent.php?del=<?php echo $eventid; ?>"><span class="glyphicon glyphicon-trash"></span></a>
					</center></td>
                    <td><center>
					</center></td>
                    
					</tr>
					</center>
					<?php 
					} 
					?>
				  </table>
 </div>
</div>

</body>
</html>
<?php
	
}
else
{
	?>
    <script>alert('not connected ');</script>
    <?php
	
}
?>
