<?php
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server
$db = mysql_select_db("IEEE", $connection); // Selecting Database from Server
// Fetching variables of the form which travels in URL

if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$name = $_POST['name'];
$email = $_POST['email'];
$subject=$_POST['subject'];
$message =$_POST['message'];
$to="salmahom02@gmail.com";
mail( $to, $subject, $message, "From:". $name);
$success = "sent";
if($name !=''|| $email !='' || $subject !='' || $message !='' ) {
//Insert Query of SQL

$query = mysql_query("insert into Feedback(Name, Email,Subject,Message) values ('$name' , '$email' , '$subject' , '$message' )");
echo "<script>
alert('Thank You we will reach You');
window.location.href='contact.html';
</script>";

	
}
}
else{
	echo "<script>
alert('Insertion Failed <br/> Some Fields are Blank....!!');
window.location.href='contact.html';
</script>";

}


mysql_close($connection); // Closing Connection with Server
?>







