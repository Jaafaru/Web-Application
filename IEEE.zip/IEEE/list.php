<?php 
session_start();
?>
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Admin Page</title>
<style>
body {
background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
}
#adminPanel {
position: absolute;
left: 261px;
top: 203px;
width: 727px;
}
#admin{
position: absolute;
font-size: 60px;
font-family: Arial, Helvetica, sans-serif;
color: #FFF;
left: 326px;
top: 32px;
width: 611px;
text-align: center;
}
#ad{
position: absolute;
left: 1050px;
top: 17px;
width: 169px;
height: 175px;
}
#use{
	position: absolute;
	left: 20px;
	top: 105px;
	height: 60px;
	width: 583px;
	color: #FFF;
	font-size: 25px;
}
#mid{
	position: absolute;
	left: 311px;
	top: 321px;
	width: 650px;
	height: 429px;
	color:#FFF;
	background-color:#666;
}
</style>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
</head>
<body>
<div id="adminPanel">
  <ul id="MenuBar1" class="MenuBarHorizontal">
    <li><a href="#">Members</a></li>
    <li><a href="#">Events</a></li>
    <li><a href="#">Feedback</a></li>
  </ul>
</div>

<label id="admin"> ADMIN PANEL</label>
<label id="ad"> <a href="logout.php" target="_blank"> 
<img src="red-logout.png" width="169" height="180"></a></label>

<span id="use"> 
<p>You have successfully logged in <?php echo $_SESSION['username']; ?></p></span>

<div class="panel panel-info" id="mid">
				<div class="panel-heading">MEMBERS</div>
				  <div class="panel-body">
				  <?php	$getdata = "SELECT * FROM teacher"; 
					$data_res = mysql_query($getdata) or die ("invalid SQL query ".mysql_error());?>
					
				  <table width="651" height="209"  class="table table-bordered">
					<thead>
								<tr class ="active">
								<td><center>Username</center></td>
								<td><center>IC No</center></td>
								<td><center>Email</center></td>
								<td><center>Fullname</center></td>
								<td><center>Phone</center></td>
								<td><center>Gender</center></td>
								<td><center>Operation</center></td>
								</tr>
					</thead>
				  
					<?php
				

					while($row = mysql_fetch_array($data_res))
					{
						 $username = $row['username'];
						 $noICTeacher = $row['noICTeacher'];
						 $email = $row['email'];
						 $fullname = $row['fullname'];
						 $phone = $row['phone'];
						 $gender = $row['gender'];
						
					?>
					<center>
					<tr>
					
					<td><?php echo "".$username ?></a></td>
					<td><?php echo "".$noICTeacher ?></td>
					<td><?php echo "".$email ?></td>
					<td><?php echo "".$fullname ?></td>
					<td><?php echo "".$phone ?></td>
					<td><?php echo "".$gender ?></td>
					<td><center><a href="ADMIN_delete_teacher.php?del=<?php echo $username; ?>"><span class="glyphicon glyphicon-trash"></span></a>
					</center></td>
					</tr>
					</center>
					<?php 
					} 
					?>
				  </table>
 </div>
</div>




<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>
