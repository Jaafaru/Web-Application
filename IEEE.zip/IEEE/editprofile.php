<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Edit Profile</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- CSS for homepage -->
    <link href="css/home.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
  body {
background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
}
#use{
	position: absolute;
	left: 5px;
	top: 69px;
	height: 60px;
	width: 100%;
	color: #FFF;
	font-size: 25px;
} 
#mve{
	position: absolute;
	color: #000;
	background-color: #CCC;
	left: 309px;
	top: 202px;
	width: 526px;
	height: 605px;
	text-align: center;
	font-size: 15px;
}
.form-horizontal{
	text-align: center;
	position: absolute;
	left: 75px;
	top: 15px;
	width: 314px;
	height: 258px;
}
h1{
	color:#CF0;
	background-color:#000;
	width:100%;
	text-align:center;
	font-family:Verdana, Geneva, sans-serif;
	font-size:35px;
  
}

  
  
    </style>
    
    
    
  </head>
  
 <?php 

session_start();

mysql_connect("localhost", "root", "")or die("cannot connect to server");
mysql_select_db("IEEE")or die("cannot select db"); 

if(isset($_SESSION['username']))
{

	$username = $_SESSION['username']

?>
  
<body>
<h1>Welcome to the MEMBER Panel</h1></a>
    <span id="use"> 
<p>You have successfully logged in as <?php echo "".$_SESSION['username']; ?></p></span>
    
        
      <div class="col-md-10" id="mve">
                    <form action="edit_funt.php" method="post" class="form-horizontal" role="form" enctype="multipart/form-data">
                        <div class="container">
                            <h1>Edit Profile</h1>
                            <br><br>
                            
                           <?php
                            //get user data
                            $showuser = "SELECT * FROM students WHERE email = '$username'";
                            $showuser_res = mysql_query($showuser) or die ("SQL Statement failed" .mysql_error());
                                
                            while ($row = mysql_fetch_array($showuser_res))
                            {
                                $firstname = $row['firstName'];
                                $lastname = $row['lastName'];
                                $phone = $row['phone'];
								$email = $row['email'];
				                $address = $row['address'];
								$field = $row['field'];
								$comments = $row['Comments'];
								$hobbies = $row['Hobbies'];
								$image = $row['Image'];
								
                                
								
                                  }
							
							if($image== null)
							{
								$image = "default.jpg";
							}
                                
                            //display user data
                            echo"
							
                                
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>Profile Picture :</label>
                                <div class='col-sm-5'>
                                    <div class='col-sm-4 thumb'>
										<a class='thumbnail' data-image-id='' data-toggle='modal' data-image='http://localhost/IEEE/uploadedfiles/$image' data-target='#image-gallery'>
											<img src='../image/$image'>
										</a>
									</div>
                                </div>
                            </div>
								<div class='form-group'>
                                <label class='control-label col-sm-3' for='pp_change'>Change Profile Picture :</label>
                                <div class='col-sm-5'>
                                    <input type='file' accept='image/*' name='image' id='image'>
                                </div>
                            </div>
							
							
							
							<div class='form-group'>
                                <label class='control-label col-sm-2'>First Name :</label>
                                <div class='col-sm-5'>
                                   <input class='form-control' type='text'  name='firstname' required value='$firstname'>
                                </div>
                            </div>
							
							<div class='form-group'>
                                <label class='control-label col-sm-2'>Last Name :</label>
                                <div class='col-sm-5'>
                                   <input class='form-control' type='text' name='lastname' required value='  $lastname'>
                                </div>
                            </div>
							
							<div class='form-group'>
                                <label class='control-label col-sm-2'>Phone :</label>
                                <div class='col-sm-5'>
                                    <input class='form-control' type='text' name='phone' required value=' $phone'>
                                </div>
                            </div>
							
							<div class='form-group'>
                                <label class='control-label col-sm-2'>Email :</label>
                                <div class='col-sm-5'>
                                    <input class='form-control' type='text' name='email' required value='$email'>
                                </div>
                            </div>
							
							<div class='form-group'>
                                <label class='control-label col-sm-2'>Address :</label>
                                <div class='col-sm-5'>
                                    <input class='form-control' type='text' name='address' required value='$address'>
                                </div>
                            </div>
							
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>Field Of study :</label>
                                <div class='col-sm-5'>
                                    <input class='form-control' type='text' name='field' required value='$field '>
                                </div>
                            </div>
                           
                            <div class='form-group'>
                                <label class='control-label col-sm-2'>Comments :</label>
                                <div class='col-sm-5'>
                                   <input class='form-control' type='text' name='comments' required value='$comments'>
                                </div>
                            </div>
							<div class='form-group'>
                                <label class='control-label col-sm-2'>Hobbies:</label>
                                <div class='col-sm-5'>
                                   <input class='form-control' type='text' name='hobbies' required value='$hobbies'>
                                </div>
                            </div>
							
                            ";
                           
                                
                                
                            
                            
                            ?>
                            <button type="reset" class="btn btn-default">Reset</button>
                            <button type="button" class="btn btn-default" onClick="canceledit()">Cancel</button>
                            <button type="submit" name="submit" class="btn btn-primary">Update Profile</button>
                            <script>
							function canceledit()
							{
								if(confirm("Are you sure you want to cancel edit your profile?")==true)
								{
									window.location.assign("http://localhost/IEEE/mana.php");
								}
							}
							
							</script>
                            
                        </div><!--end of container-->
                    </form>
                </div><!--end of col-md-10-->
                
            </div><!--end of row-->
        </div><!--end of container-fluid-->
    

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>
  
  <?php
	}
	else
	{
		?>
        	<script>
				window.location.assign("http://localhost/IEEE/mana.php");
			</script>
        <?php
	}
  ?>
  
</html>