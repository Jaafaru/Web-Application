  
 <?php 

session_start();

mysql_connect("localhost", "root", "")or die("cannot connect to server");
mysql_select_db("IEEE")or die("cannot select db"); 



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Search results</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="style.css"/>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="css2/bootstrap.css" />
    <link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    
   <style>
  body {
background-image: url(12927553-Dark-blue-technology-background-Stock-Photo-technical.jpg);
}



#use{
	position: absolute;
	left: 20px;
	top: 105px;
	height: 60px;
	width: 583px;
	color: #FFF;
	font-size: 25px;
}
#mid{
	position: absolute;
	left: 282px;
	top: 298px;
	width: 739px;
	height: 215px;
	color: #FFF;
	background-color: #CFF;
}
#panel-heading{
	color:#009;
	font-size:36px;
}
h1{
	color:#CF0;
	background-color:#000;
	width:100%;
	text-align:center;
	font-family:Verdana, Geneva, sans-serif;
	font-size:35px;
  
}
table{
	position: absolute;
	left: 2px;
	top: 66px;
	height: 141px;
}
.panel-body{
	font-size:14px;
	font-family:Arial, Helvetica, sans-serif;
}
  #wrap{
	background-color: #FFF;
	width: 100%;
	position: absolute;
	left: 1px;
	top: 129px;
	height:100%;
  }
  
 #use{
	position: absolute;
	left: 5px;
	top: 69px;
	height: 60px;
	width: 100%;
	color: #FFF;
	font-size: 25px;
} 
#panel-heading{
	color:#333;
	font-size:36px;
}
#logo{
position: absolute;
display: block;
width: 253px;
height: 111px;
left: 11px;
top: 5px;
}
#menu{
position: absolute;
width: 1220px;
top: 131px;
height: 79px;
left: 101px;
}
#title{
font-family: Cambria, "Hoefler Text", "Liberation Serif", Times, "Times New Roman", serif;
font-size: 44px;
color:white;
position: absolute;
top: 27px;
left: 503px;
width: 584px;
height: 71px;
}
#uum{
position: absolute;
left: 1149px;
top: 3px;
width: 126px;
height: 121px;
}
#ad{
position: absolute;
left: 1050px;
top: 17px;
width: 169px;
height: 175px;
}
#menu{
	position: absolute;
	width: 1220px;
	top: 131px;
	height: 79px;
	left: 101px;
	}
	#sear{
	position: absolute;
	left: 1000px;
	top: 259px;
	}
	#display{
		position:absolute;
		
	}
	#login{
	position: absolute;
	width: 195px;
	left: 1012px;
	top: 88px;
	}
	.panel-body{
	font-size:14px;
	font-family:Arial, Helvetica, sans-serif;
}
#mid{
	
	
	color: #FFF;
	background-color:#666;
}
  
  
   </style>  
    
    
    
    
    
    
    
    
</head>
<body>
<div id="menu">
<ul id="MenuBar1" class="MenuBarHorizontal">
<li><a href="index.html">HOME</a></li>
<li><a href="about.html">ABOUT</a></li>
<li><a href="eve.php">EVENTS</a></li>
<li><a href="membership.html"> MEMBERSHIP</a></li>
<li><a href="contact.html"> CONTACT US </a></li>
</ul>
</div>
<div id="logo"><img src="eee.png" width="248" height="109"> </div>
<label id="title"> UTARA STUDENT BRANCH</label>

<label id="uum"><img src="logo-uum.jpg" width="126" height="123"></label>
<div id="login"><a href="login.html" target="_blank"> 
<img src="login.png" width="119" height="33"></a>   </div>
</div>
<div class="panel panel-info" id="mid">
<div id="panel-heading">RESULTS</div>
 <div class="panel-body">
 <?php
    $query = $_GET['query']; 
    // gets value sent over search form
     
    $min_length = 3;
    // you can set minimum length of the query if you want
     
    if(strlen($query) >= $min_length){ // if query length is more or equal minimum length then
         
        $query = htmlspecialchars($query); 
        // changes characters used in html to their equivalents, for example: < to &gt;
         
        $query = mysql_real_escape_string($query);
        // makes sure nobody uses SQL injection
         
        $raw_results = mysql_query("SELECT * FROM EVENTS
            WHERE (Topic LIKE '%".$query."%') OR (Date LIKE '%".$query."%')") or die(mysql_error());
             
        
        if(mysql_num_rows($raw_results) > 0){ // if one or more rows are returned do following
             
            while($results = mysql_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
             
                echo "<p ><h3>".$results['Topic']."</h3>".$results['Date']."</p>";
                // posts results gotten from database(title and text) you can also show id ($results['id'])
            }
             
        }
        else{ // if there is no matching rows do following
            echo "No results";
        }
         
    }
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }
?>
 </div>
</div>

</body>
</html>