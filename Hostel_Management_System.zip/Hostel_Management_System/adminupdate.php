<html>
<head>
</head>
<body>
<link rel="stylesheet" href="css/style.css">
<?php session_start(); ?>
<div class="body content">
    <div class="welcome">
        
        
        <h1>Welcome <span class="user"><?= $_SESSION['userName'] ?></span></h1>
        <?php
        $mysqli = new mysqli("localhost", "root", "", "pavic_database");
        
		if(isset($_POST['update'])){
			$UpdateQury = "UPDATE concert SET artist='$_POST[artist]',venue='$_POST[venue]',time='$_POST[time]',price='$_POST[price]' WHERE artist='$_POST[hidden]'";
			mysqli_query($mysqli,$UpdateQury);
		};
		
		//Select queries return a resultset
        $id='1';
		$sql = "SELECT artist,venue,time,price FROM concert ";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
		/*if($result){
			echo "Update Successful";
		}
		else{
			echo "Error Occurred, Update Failed!"; 
		}*/
        ?>
        <div id='registered'>
        <span><h2>Concert Details:<h2></span>
        <?php
		echo "<table>
		<tr>
		<th>Artist</th>
		<th>Venue</th>
		<th>Time</th>
		<th>Price</th>
		</tr>";
        while($row = $result->fetch_assoc()){ //returns associative array of fetched row
		echo "<form action=adminupdate.php method=post>";

            echo "<tr>";
			echo "<td>" . "<input type=text name=artist value=" . $row['artist'] . " </td>";
			echo "<td>" . "<input type=text name=venue value=" . $row['venue'] . " </td>";
			echo "<td>" . "<input type=text name=time value=" . $row['time'] . " </td>";
            echo "<td>" . "<input type=text name=price value=" . $row['price'] . " </td>";
			echo "<td>" . "<input type=hidden name=hidden value=" . $row['artist']. " </td>";
			echo "<td>" . "<input type=submit name=update value=update />" . " </td>";
			echo "</tr>";
			echo "</form>";
        }
		
		echo "</table>";
		if($result==TRUE){
			echo "Update Successful";
		}
		else{
			echo "Error Occurred, Update Failed!"; 
		}
        ?>  
        </div>
    </div>
</div>

</body>
</html>