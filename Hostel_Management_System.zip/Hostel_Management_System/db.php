<html>
<head>
<title>Database Connection</title>
</head>
<body>
<?php  
    $con=mysqli_connect('localhost','root','root');
    $db=mysqli_select_db($con,'pavic_database');
    
    if($con){
        echo "Connection is successful to the database you are now connected to KB". "<br>";
        
    }else{
        die('Error.');
    }
    
    if($db){
        echo "The requested DB exists". "<br>";
        
    
    }else{
        die('You do not know the fucking DB that you want to connect to eh?');
    }
?>
    <br>
    <br>
    
    <?php
        
        $query="SELECT * FROM users";
        $result=mysqli_query($con,$query);
        
        if(mysqli_num_rows($result)>0){
            
            while($row = mysqli_fetch_assoc($result)){
                echo "id: " . $row["id"]. " - Name: " . $row["name"]. " - Email: " . $row["email"].  " - Brid: " . $row["brid"]. "<br>";
            }
        }else{
            echo "Fuck man we stuck here!";
        }
    
    
   
    
    ?>
</body>
</html>﻿ 