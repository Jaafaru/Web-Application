<?php

error_reporting(E_ALL ^ E_DEPRECATED);

$username = $_POST['username'];
$password = $_POST['Password'];

mysql_connect("localhost", "root", "");
mysql_select_db("elninolibrary");


$result = mysql_query("select * from adlogin where username = '$username' and Password = '$password'") or die ("Failed to query database" .mysql_error());

$row = mysql_fetch_array($result);

if ($row['username'] == $username && $row['Password'] == $password)
{
	echo "Login Successful".$row['username'];
header("Location: admin_view.php");
}
else {
	echo "Access denied!";
}
?>