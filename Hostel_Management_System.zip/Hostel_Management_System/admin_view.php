<html>
<head><title>Records</title>
<link rel="stylesheet" type="text/css" href="viewcss.css" />
</head>

 <body>
  <div id="content"> 
    <?php
	 include('connection.php');
	 $result = mysql_query("SELECT * FROM books") or die(mysql_error());
	
	echo "<p align='center'><b><strong>BOOK LIST</strong></b></p>";
	echo "<table border='1' width='849' align='center' cellspacing='2' cellpadding='10'>";
	echo "<tr>
		    <td> <strong>No</strong></td>
			<td><strong>Name</strong></td>
			<td><strong>Location</strong></td>
			<td><strong>Quantity</strong></td>
			<td><strong>Edit</strong></td>
			<td><strong>Delete</strong></td>
		 </tr>";
	  
	 while($row = mysql_fetch_array( $result ))
		{
			echo "<tr>";
			echo '<td>' . $row['no']. '</td>';
			echo '<td>' . $row['name']. '</td>';
			echo '<td>' . $row['location']. '</td>';
			echo '<td>' . $row['quantity']. '</td>';
			echo '<td><a href="EDIT.php?id=' .$row['no'].'">Edit</a></td>';
			echo '<td><a href="DELETE.php?id=' .$row['no'].'">Delete</a></td>';
		    echo "</tr>";
		  }
		 echo "</table>";
		 
		?>
        <p align="center"><a href="INSERT.php">ADD BOOK</a></p>
		 </div>
 </body>

</html>