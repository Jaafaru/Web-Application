<head>
  <title>INASIS ONLINE ROOM BOOKING SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script>
	
  </script> 
</head>

<body>
<div id="main">
<header>
  <div id="logo">
	<div id="logo_text">
	  
	   <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>

	</div>
   
  </div>
  <nav>
	<ul class="sf-menu" id="nav">
	   <li class="current"><a href="index.html">Home</a></li>
<li><a href="about.html">About Us</a></li>

<li><a href="login.html">Login</a></li>
	 
	   <li><a href="register.html">Register</a></li>

	 
	  <li><a href="contact.html">Contact Us</a></li>

			</ul>
		</ul>
	  </li>

	</ul>
  </nav>
</header>
	   <div id="site_content">
	   <div class="content">
<?php session_start(); ?>
<div class="body content">
    <div class="welcome">
       
        
        <h1>Welcome back <span class="user"><?= $_SESSION['userName'] ?></span></h1>
        <?php
        $mysqli = new mysqli("localhost", "root", "", "inasis");
        //Select queries return a resultset
        $sql = "SELECT * FROM users";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
        ?>
        <div id='registered'>
			Go to manage rooms to manage blocks and rooms...
			<div style="float: left">
				<nav>
        <ul class="sf-menu" id="nav">
          
 <li><a href="manage.html">Manage Rooms</a></li>
            </ul>
          </li>
      </nav>
		</div>
        <span><h2>All users:<h2></span>
        <?php
		echo "<table align=center>
		<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email</th>
		<th>Gender</th>
		<th>Username</th>
		<th>Password</th>
		<th>Manage</th>
		</tr>";
        while($row = $result->fetch_assoc()){ //returns associative array of fetched row
            //echo '<pre>';
            //print_r($row);
            //echo '</pre>';
            echo "<tr><td>$row[firstname]</span></td><td>$row[lastname]</span></td><td><div class='userlist'><span>$row[email]</span>";"</td>";
            echo "<td>$row[gender]<td>$row[user]<td>$row[password]</div><td><a href='adminview.php?idd=$row[id]'>Delete</a>";"</td></tr></table>";
			
			 
        }
		if(isset($_GET['idd'])){
			$idd = $_GET['idd'];
			$delsql = "delete from users where id='$idd'";
			$query = $mysqli->query($delsql);
			if($delsql){
				?>
				<script>
					alert("Successfully deleted data");
					window.location.href='adminview.php';
				</script>
				<?php
				header("Location: adminview.php");
			}
			else{
				?>
				<script>
					alert("Failed to delete data");
					window.location.href='adminview.php';
				</script>
				<?php
			}
		}
        ?>  
        </div>
    </div>
</div>
		   </div>
		   </div> 
		   </div>