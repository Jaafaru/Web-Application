<?php

    session_start();
    $hostname = 'localhost';
    $dbname   = 'inasis';
    $username = 'root'; 
    $password = '';
	
    $con = new mysqli($hostname, $username, $password, $dbname);
    //mysql_select_db($con,$dbname) or DIE('Database name is not available!');

    $userName=mysqli_real_escape_string($con,$_POST['user']); 
    $passWord=md5(mysqli_real_escape_string($con,$_POST['pass'])); 
    $query = "SELECT * FROM login WHERE usname='$_POST[user]' AND  pass='$_POST[pass]'";
    $res = mysqli_query($con,$query);
    $rows = mysqli_num_rows($res);
   
	if ($rows==1) 
    {
        $_SESSION['userName'] = $_POST['user'];
		echo "Succesfully Logedin";
        header("Location: adminview.php");
    }
    else 
    {
        echo "user name and password not found <br/>
                Click <a href=adminlogin.html>here</a> to relogin";
        echo "<script>
                    alert('Wrong username or password');
                    window.location.href='adminlogin.html';
                </script>";        
        // TODO - replace message with redirection to login page
        //  header("Location: index.html");
    }