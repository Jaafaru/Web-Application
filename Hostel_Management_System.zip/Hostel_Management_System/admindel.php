<html>
<head>
</head>
<body>
<link rel="stylesheet" href="css/style.css">
<?php
$mysqli = new mysqli("localhost", "root", "", "pavic_database");
$artist="";
//$artist = $_GET['artist']; 
if (isset($_GET['artist']))
{
// get id value
$artist = $_GET['artist'];

// delete the entry
$result = "DELETE FROM concert WHERE artist=$artist";
			mysqli_query($mysqli,$result);


// redirect back to the view page

header("Location: adminconcertmanage.php");

}

else

// if id isn't set, or isn't valid, redirect back to view page

{
echo "Delete Unsuccesful!";

}
?>