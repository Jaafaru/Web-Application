<link rel="stylesheet" href="css/style.css">
<?php session_start(); ?>
<div class="body content">
    <div class="welcome">
       
        
        <h1>Welcome <span class="user"><?= $_SESSION['userName'] ?></span></h1>
        <?php
        $mysqli = new mysqli("localhost", "root", "", "pavic_database");
        //Select queries return a resultset
        $sql = "SELECT * FROM concert";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
        ?>
        <div id='registered'>
        <span>Even details:</span> <a style=float:right; href=adminadd.php>Add new Concert</a>
		<table>
		<tr>
		<th>Artist</th>
		<th>Venue</th>
		<th>Time</th>
		<th>Price</th>
		<th colspan=2>Manage</th>
		</tr>
		<?php
        while($row = mysqli_fetch_array($result)){ //returns associative array of fetched row
            //echo '<pre>';
            //print_r($row);
            //echo '</pre>';
            echo "<tr><td>$row[artist]</span></td><td>$row[venue]</span></td><td><div class='userlist'><span>$row[time]</span>";"</td>";
             echo "<td>$row[price]</div><td><a href=adminupdate.php>Update</a></td><td><a href=admindel.php>Delete</a>";"</td></tr></table>";
        }
        ?> 
		
        </div>
		
    </div>
</div>
