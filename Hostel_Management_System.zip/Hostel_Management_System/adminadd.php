<head>
  <title>INASIS ONLINE ROOM BOOKING SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script>
	
  </script> 
</head>

<body>
<div id="main">
<header>
	<div id="logo">
		<div id="logo_text">
			
			 <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>

		</div>
	 
	</div>
	<nav>
		<ul class="sf-menu" id="nav">
			 <li class="current"><a href="index.html">Home</a></li>
<li><a href="about.html">About Us</a></li>

<li><a href="login.html">Login</a></li>
		 
	 <li><a href="register.html">Register</a></li>

		 
			<li><a href="contact.html">Contact Us</a></li>

						</ul>
				</ul>
			</li>

		</ul>
	</nav>
</header>
	   <div id="site_content">
	   <div class="content">
		   <p>Add new rooms to Block A</p>
		   <form action="adminadd.php" method="post" enctype="multipart/form-data">
		   	   <input type="file" name="image" required />
			   <input type="text" name="block" value="Block A" />
			   <input type="text" name="price" placeholder="Price in RM" required/>
			   <input type="submit" name="submit" value="Add" />		   
		   </form>
<?php
		   $mysqli = new mysqli("localhost","root","","inasis");
			 $msg = "";	
			 $result = mysqli_query($mysqli, "SELECT * FROM rooms");
			 while($row = mysqli_fetch_array($result)){
				echo "<table><tr><td><img src='images/$row[roomimage]' width=350 height=200 /></td>";
				echo "<td>".$row['price']."</td>";
				echo "<td>".$row['block']."</td>";
				echo "<td><a href='adminadd.php?idd=$row[id]'>Delete</a></td></tr></table>";
			}    
		   if(isset($_POST['submit'])){
			   $block = $_POST['block'];
		   	   $price = $_POST['price'];
			   $target_dir = "images/";
			   $target_file = $target_dir . basename($_FILES['image']['name']);
			  // $mysqli = mysqli_connect("localhost","root","","inasis");
			   $image = $_FILES['image']['name'];
				// Get text
				$block = mysqli_real_escape_string($mysqli, $_POST['block']);
						   $price = mysqli_real_escape_string($mysqli, $_POST['price']);

				// image file directory
				$sql = "INSERT INTO rooms (roomimage, block, price) VALUES ('$image', '$block', '$price')";
				// execute query
				mysqli_query($mysqli, $sql);

				if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
					$msg = "<div id='alert alert-success'> Image uploaded successfully </div>";
				}else{
					$msg = "Failed to upload image";
				}
				?>
				<script>
					alert("Successfully added room");
					window.location.href='adminadd.php';
				</script>
				<?php
			}
			 if(isset($_GET['idd'])){
				$idd = $_GET['idd'];
				$delsql = "delete from rooms where id='$idd'";
				$query = $mysqli->query($delsql);
				if($delsql){
					?>
					<script>
						alert("Successfully deleted data");
						window.location.href='adminadd.php';
					</script>
					<?php
					//header("Location: adminadd.php");

				}
				else{
					?>
					<script>
						alert("Failed to delete data");
						window.location.href='adminadd.php';
					</script>
					<?php
				}
			
			}
		
			  
		   
?>

		</div>
	  </div>
	</div>







