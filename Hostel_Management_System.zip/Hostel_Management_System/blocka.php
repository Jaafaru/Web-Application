<head>
  <title>INASIS ONLINE ROOM BOOKING SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script>
	
  </script> 
</head>

<body>
<div id="main">
<header>
	<div id="logo">
		<div id="logo_text">
			
			 <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>

		</div>
	 
	</div>
	<nav>
		<ul class="sf-menu" id="nav">
			 <li class="current"><a href="index.html">Home</a></li>
<li><a href="about.html">About Us</a></li>

<li><a href="login.html">Login</a></li>
		 
	 <li><a href="register.html">Register</a></li>

		 
			<li><a href="contact.html">Contact Us</a></li>

						</ul>
				</ul>
			</li>

		</ul>
	</nav>
</header>
	   <div id="site_content">
	   <div class="content">
       <p>Apply for rooms in Block B</p>
<?php
session_start();
           $mysqli = new mysqli("localhost","root","","inasis");
           $query = mysqli_query($mysqli,"Select * from rooms") or die("Server Error");
           if($query==true){
                while($row=mysqli_fetch_array($query)){
                echo "<table><tr><td><img src='images/$row[roomimage]' width=350 height=200 /></td>";
				echo "<td>".$row['price']."</td>";
				echo "<td>".$row['block']."</td>";
				echo "<td><a href='blocka.php?idd=$row[id]'>Book</a></td></tr></table>";
                }
                if(isset($_GET['idd'])){
                    $idd = $_GET['idd'];
                $delsql = "INSERT INTO bookings values id='$idd',user='$_SESSION[userName]',block='$row[block]',price='$row[price]'";
                $query = $mysqli->query($delsql);
                if($delsql=true){
                    ?>
                    <script>
                        alert("Booking Successfull, Thanks for using INASIS ONLINE to book!");
                        window.location.href='blocka.php';
                    </script>
                    <?php
                }
                else{
                    ?>
                    <script>
                        alert("Failed to delete data");
                        window.location.href='blockb.php';
                    </script>
                    <?php
                }
            
            }
                
                    
                }
           else{
            ?>
            <script>
                alert("Booking Unsuccessful");
                window.location.href='blocka.php';
            </script>
            <?php 
           }
           