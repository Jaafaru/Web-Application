<head>
  <title>INASIS ONLINE ROOM BOOKING SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
 
</head>

<body>
  <div id="main">
  <header>
	<div id="logo">
		<div id="logo_text">
			
			 <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>

		</div>
	 
	</div>
	<nav>
		<ul class="sf-menu" id="nav">
			 <li class="current"><a href="index.html">Home</a></li>
<li><a href="about.html">About Us</a></li>

<li><a href="login.html">Login</a></li>
		 
	 <li><a href="register.html">Register</a></li>

		 
			<li><a href="contact.html">Contact Us</a></li>

						</ul>
				</ul>
			</li>

		</ul>
	</nav>
</header>
	   <div id="site_content">
	   <div class="content">
     <div style=float:right;><a href="userupdate.php"><input type=submit name=update value="Update Profile" /></a></div><div style=float:right;><a href="userblock.html"><input type=submit name=update value="Go to Blocks" /></a></div>
     <div style=float:right;>
                    <form action="search.php" method="post">
                    <input type=text name=search placeholder="Type to search" />
                    <input type=submit value=Search />
                    </form>
                     </div>
<?php
$servername="localhost";
$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$email = $_POST["email"];
//$inputpass = $mysqli->escape_string(password_hash($_POST['password'], PASSWORD_BCRYPT));
//$hash = $_POST [$mysqli->( md5( rand(0,1000) ) )]	;
//$cnum = $_POST["cnum]"];
$gender = $_POST["gender"];
$inputuser = $_POST["user"];
$inputpass = $_POST["password"];
$usern = "root";
$password = "";
$database = "inasis";


 $con = new mysqli($servername, $usern, $password, $database);

/*if($mysqli->connect_error) {
    die("Connection failed:" . $con->connect_error);
}*/
 session_start();
 $userName = $_POST['firstname'];
 $userName=mysqli_real_escape_string($con,$_POST['firstname']); 
 $sql = "INSERT INTO users(firstname,lastname,email,gender,user,password) VALUES ('$firstname','$lastname','$email','$gender','$inputuser','$inputpass')";

 if($con->query($sql)=== TRUE){
	 echo "Data is added";
	 //header("Location: userview.php");
	 echo "<div class=welcome>";
       $_SESSION['userName']=$_POST['firstname'];
	   // echo " <div class=alert alert-success>" . $_SESSION['message']; " </div>";
        
       echo " Welcome <span class=user>". $_SESSION['userName'] ;" </span>";
        //<?php
        $mysqli = new mysqli("localhost", "root", "", "inasis");
        //Select queries return a resultset
        $sql = "SELECT firstname,lastname,email,gender,user,password FROM users WHERE user='$_POST[user]'";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
       //?
       echo "<div id='registered'>";
       echo "<span><h2>Your Details:<h2></span><div style=float:center;><a href=userupdate.php><input type=submit name=update value='Update Profile' /></a></div>";
        //<?php
		echo "<table>
		<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email</th>
		<th>Gender</th>
		<th>Matric no</th>
		<th>Password</th>
		</tr>";
        while($row = $result->fetch_assoc()){ //returns associative array of fetched row
            //echo '<pre>';
            //print_r($row);
            //echo '</pre>';
            echo "<tr><td>$row[firstname]</span></td><td>$row[lastname]</span></td><td>$row[email]</span></td><td><div class='userlist'><span>$row[gender]</span>";"</td>";
             echo "<td>$row[user]<td>$row[password]</td></div>";"</td></tr></table>";
        }
       // ?  
        echo "</div>";
 }
 
 else{
	 echo "Error".$sql."br".$con->error;
 }
 $con->close();


?>
</div>
</div>