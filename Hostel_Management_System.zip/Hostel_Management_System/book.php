<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>INASIS ONLINE ROOM BOOKING</title>
</head>

<body>
</body>
</html>