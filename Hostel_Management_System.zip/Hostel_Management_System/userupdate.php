<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Manage Blocks</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<style>
	.content { 
  text-align: left;
  width: 1045px;
  margin: 0 0 15px 0;
  background: #fff;border-bottom: 1px solid #D4D4D4;
  border: 1px solid #e5e5e5;
  border-radius: 7px 7px 7px 7px;
  -moz-border-radius: 7px 7px 7px 7px;
  -webkit-border: 7px 7px 7px 7px;
  float: left;
    }
</style>
	</head>

<body>
  <div id="main">
    <header>
      <div id="logo">
        <div id="logo_text">
          
          <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>
      
        </div>
        
      </div>
      <nav>
        <ul class="sf-menu" id="nav">
          <li class="current"><a href="index.html">Home</a></li>
 <li><a href="about.html">About Us</a></li>
  
<li><a href="login.html">Login</a></li>
         <li><a href="register.html">Register</a></li>
		   
			  
         
          <li><a href="contact.html">Contact Us</a></li>
           
            </ul>
          </li>
      </nav>
    </header>
<?php session_start(); ?>
<div class="body content">
<div style=float:right;><a href="userupdate.php"><input type=submit name=update value="Update Profile" /></a></div><div style=float:right;><a href="userblock.html"><input type=submit name=update value="Go to Blocks" /></a></div>
	   <div style=float:right;>
	   <form action="search.php" method="post">
	   <input type=text name=search placeholder="Type to search" />
	   <input type=submit value=Search />
	   </form>
        </div>
    <div class="welcome">
        
        
        <h1>Welcome <span class="user"><?= $_SESSION['userName'] ?></span></h1>
        <?php
        $mysqli = new mysqli("localhost", "root", "", "inasis");
        
		if(isset($_POST['update'])){
			$UpdateQury = "UPDATE users SET firstname='$_POST[firstname]',lastname='$_POST[lastname]',email='$_POST[email]',gender='$_POST[gender]',user='$_POST[user]',password='$_POST[password]' WHERE firstname='$_POST[hidden]'";
			mysqli_query($mysqli,$UpdateQury);
		};
		
		//Select queries return a resultset
        $id='1';
		$sql = "SELECT firstname,lastname,user,gender, email,password FROM users WHERE user='$_SESSION[userName]'";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
		/*if($result){
			echo "Update Successful";
		}
		else{
			echo "Error Occurred, Update Failed!"; 
		}*/
        ?>
        <div id='registered'>
        <span><h2>Your Details:<h2></span>
        <?php
		echo "<table>
		<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email</th>
		<th>Gender</th>
		<th>Username</th>
		<th>Password</th>
		</tr>";
        while($row = $result->fetch_assoc()){ //returns associative array of fetched row
		echo "<form action=userupdate.php method=post>";

            echo "<tr>";
			echo "<td>" . "<input type=text name=firstname value=" . $row['firstname'] . " </td>";
			echo "<td>" . "<input type=text name=lastname value=" . $row['lastname'] . " </td>";
			echo "<td>" . "<input type=email name=email value=" . $row['email'] . " </td>";
			echo "<td>" . "<input type=text name=gender value=" . $row['gender'] . " </td>";
			echo "<td>" . "<input type=text name=user value=" . $row['user'] . " </td>";
            echo "<td>" . "<input type=text name=password value=" . $row['password'] . " </td>";
			echo "<td>" . "<input type=hidden name=hidden value=" . $row['firstname']. " </td>";
			echo "<td>" . "<input type=submit name=update value=update />" . " </td>";
			echo "</tr>";
			echo "</form>";
        }
		
		echo "</table>";
			$error = "";
		if(isset($_POST['update'])){
			echo "Update Successful";
		}
		elseif(mysqli_error($mysqli)){
			$error = "Error Occurred, Update Failed!"; 
			echo $error;
		}
        ?>  
        </div>
    </div>
</div>

</body>
</html>