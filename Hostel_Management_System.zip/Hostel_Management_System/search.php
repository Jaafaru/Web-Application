<head>
  <title>INASIS ONLINE ROOM BOOKING SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script>
	
  </script> 
</head>

<body>
  <div id="main">
    <header>
      <div id="logo">
        <div id="logo_text">
          
          <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>
      
        </div>
        
      </div>
      <nav>
        <ul class="sf-menu" id="nav">
          <li class="current"><a href="index.html">Home</a></li>
 <li><a href="about.html">About Us</a></li>
  
<li><a href="login.html">Login</a></li>
         <li><a href="register.html">Register</a></li>
		   
			  
         
          <li><a href="contact.html">Contact Us</a></li>
           
            </ul>
          </li>
      </nav>
    </header>
	   <div id="site_content">
	   <div class="content">
           <h3>Showing Search results...</h3>
<?php
    session_start();
	$output = '';
    $mysqli = new mysqli("localhost", "root", "", "inasis");
    //$search = $_POST['search'];
	if (isset($_POST['search'])){
		$searchR = $_POST['search'];
        $searchR = preg_replace("#[^0-9a-z]#i","",$searchR);
        $block = "block";
		$squery = mysqli_query($mysqli,"SELECT * FROM rooms WHERE $block LIKE '%$searchR%' OR price LIKE '%$searchR%' UNION SELECT * FROM rooms WHERE $block LIKE '%$searchR%' OR price LIKE '%$searchR%'") or die("Could not search!");
		//$squery = mysqli_query($mysqli,"SELECT rooms.*,roomb.* FROM rooms,roomsb WHERE $block LIKE '%$searchR%' OR price LIKE '%$searchR%'") or die("Could not search!");
		$count = mysqli_num_rows($squery);
		if ($count == 0){
			$output = 'No result found!';
			echo $output;
		}
		else{
			while($row = mysqli_fetch_array($squery)){
				$blocks=$row['block'];
                $price=$row['price'];
                $room=$row['roomimage'];
				$id=$row['id'];
				
                $output .= '<div><table><tr><td>'."<img src='images/$room' width=350 height=200 /></td><td>".$blocks."</td><td>".$price.
                "<td><a href='search.php?idd=$row[id]'>Book</a></td></tr></table></div>";
				echo $output;
            }
        }
    }
    if(isset($_GET['idd'])){
        $idd = $_GET['idd'];
        $user=$_SESSION['userName'];
        $searchR = $_GET['idd'];
        //$searchR = preg_replace("#[^0-9a-z]#i","",$searchR);
        $block = "block";
        $squery = mysqli_query($mysqli,"SELECT * FROM rooms") or die("Could not perform operation!");
        while($row = mysqli_fetch_array($squery)){
        $blk=$row['block'];
        $price=$row['price'];
        $delsql = "INSERT INTO bookings(id,users,blk,price) values('$idd','$user','$blk','$price')";
        $query = $mysqli->query($delsql);
        if($delsql){
            ?>
            <script>
                alert("Your booking has been processed. Thanks for using INASIS");
                window.location.href='index.html';
            </script>
            <?php
            
        }
        else{
            ?>
            <script>
                alert("Failed to process booking");
                window.location.href='search.php';
            </script>
            <?php
        }
    }
    }
	?>

        </div>
</div>
</div>