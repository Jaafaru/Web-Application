<link rel="stylesheet" href="css/style.css">
<?php
$servername="localhost";

$inputuser = $_POST["user"];
$user = "root";
$password = "";
$database = "pavic_database";


 $con = new mysqli($servername, $user, $password, $database);

/*if($mysqli->connect_error) {
    die("Connection failed:" . $con->connect_error);
}*/

 session_start();
 
 $userName = $_POST['user'];
 $artist = $_POST['artist'];
 $venue = $_POST['venue'];
 $time = $_POST['time'];
 $price = $_POST['price'];
 $userName=mysqli_real_escape_string($con,$_POST['user']); 
 $sql = "INSERT INTO reserve(user,artist,venue,time,price) VALUES ('$userName','$artist','$venue','$time','$price')";

 if($con->query($sql)=== TRUE){
	 echo "Data is added";
	 //header("Location: userview.php");
	 echo "<div class=welcome>";
       $_SESSION['userName']=$_POST['user'];
	   // echo " <div class=alert alert-success>" . $_SESSION['message']; " </div>";
        
       echo " Welcome <span class=user>". $_SESSION['userName'] ;" </span>";
        //<?php
        $mysqli = new mysqli("localhost", "root", "", "pavic_database");
        //Select queries return a resultset
        $sql = "SELECT * FROM reserve WHERE user='$_SESSION[userName]'";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
       //?
       echo "<div id='registered'>";
       echo "<span><h2>Your Ticket Details:<h2></span><div style=float:center;><a href=concerts.html>Back to Concerts</a></div>";
        //<?php
		echo "<table>
		<tr>
		<th>Ticket</th>
		<th>Artist</th>
		<th>Venue</th>
		<th>Time</th>
		<th>Price</th>
		</tr>";
        while($row =$result->fetch_assoc()){ //returns associative array of fetched row
            //echo '<pre>';
            //print_r($row);
            //echo '</pre>';
            echo "<tr><td>$row[tickno]</span></td><td>$row[artist]</span></td><td><div class='userlist'><span>$row[venue]</span>";"</td>";
             echo "<td>$row[time]<td>$row[price]</td></div>";"</td></tr></table>";
        }
       // ?  
        echo "</div>";
 }
 
 else{
	 echo "Error".$sql."br".$con->error;
 }

 $con->close();
?>

