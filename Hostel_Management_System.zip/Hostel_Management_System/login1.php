<?php
$servername="localhost";
$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$email = $_POST["email"]
//$cnum = $_POST["cnum]"];
//$dob = $_POST["dob"]
$inputuser = $_POST["user"];
$inputpass = $_POST["pass"];
$user = "root";
$password = "";
$database = "pavic_database";


 $con = new mysqli($servername, $user, $password, $database);

if($mysqli->connect_error) {
    die("Connection failed:" . $con->connect_error);
}
 
 
 $sql = "INSERT INTO pavic(user,password) VALUES ('$inputuser','$inputpass')";

 if($con->query($sql)=== TRUE){
	 echo "Data is added";
	 
 }
 
 else{
	 echo "Error".$sql."br".$con->error;
 }
 $con->close();


?>