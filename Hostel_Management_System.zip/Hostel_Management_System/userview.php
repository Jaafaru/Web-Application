<head>
  <title>INASIS ONLINE ROOM BOOKING SYSTEM</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script>
	
  </script> 
</head>

<body>
  <div id="main">
  <header>
  <div id="logo">
	<div id="logo_text">
	  
	  <h1><a href="index.html">INASIS<span class="logo_colour"> ONLINE ROOM BOOKING SYSTEM</span></a></h1>
  
	</div>
	
  </div>
  <nav>
	<ul class="sf-menu" id="nav">
	  <li class="current"><a href="index.html">Home</a></li>
<li><a href="about.html">About Us</a></li>

<li><a href="login.html">Login</a></li>
	 <li><a href="register.html">Register</a></li>
	   
		  
	 
	  <li><a href="contact.html">Contact Us</a></li>
	   
		</ul>
	  </li>
  </nav>
</header>
	   <div id="site_content">
	   <div class="content">
<?php session_start(); ?>

       <div style=float:right;><a href="userupdate.php"><input type=submit name=update value="Update Profile" /></a></div><div style=float:right;><a href="userblock.html"><input type=submit name=update value="Go to Blocks" /></a></div>
	   <div style=float:right;>
	   <form action="search.php" method="post">
	   <input type=text name=search placeholder="Type to search" />
	   <input type=submit value=Search />
	   </form>
        </div>

        <h1>Welcome <span class="user"><?= $_SESSION['userName'] ?></span></h1>
        <?php
        $mysqli = new mysqli("localhost", "root", "", "inasis");
        //Select queries return a resultset
        $sql = "SELECT firstname,lastname,gender,user, email,password FROM users WHERE user='$_SESSION[userName]'";
        $result = $mysqli->query($sql); //$result = mysqli_result object
        //var_dump($result);
        ?>
        <div id='registered'>
        <span><h2>Your Details:<h2></span>
        <?php
		echo "<table>
		<tr>
		<th>First Name</th>
		<th>Last Name</th>
		<th>Email</th>
		<th>Gender</th>
		<th>Username</th>
		<th>Password</th>
		</tr>";
        while($row = $result->fetch_assoc()){ //returns associative array of fetched row
            //echo '<pre>';
            //print_r($row);
            //echo '</pre>';
            echo "<tr><td>$row[firstname]</span></td><td>$row[lastname]</span></td><td><div class='userlist'><span>$row[email]</span>";"</td>";
             echo "<td>$row[gender]</td><td>$row[user]</td><td>$row[password]</td></div>";"</td></tr></table>";
        }
        ?>  
        </div>
    </div>
</div>
</div>
<?php.print("$output");?>

